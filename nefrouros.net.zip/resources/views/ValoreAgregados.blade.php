@extends('layauts.plantilla')
@section('content')
    
    <section id="faq" class="faq section-bg">
        <div class="container">
            <div class="section-title">
                <h2><span style="color: #737373;">VALORES </span> <span style="color: #f57d00;">AGREGADOS</span> </span>
                </h2>
            </div>
        </div>
        <div class="col-xl-12">
            <div class="section_title text-center mb-55">
            </div>
        </div>
        <div class="faq-list">
            <ul>
                <li data-aos="fade-up">
                    <i class="bx bx-run icon-help"></i> <a data-toggle="collapse" class="collapse" href="#faq-list-1">Aporte
                        permanente en innovación científica. <i class="bx bx-chevron-down icon-show"></i><i
                            class="bx bx-chevron-up icon-close"></i></a>
                    <div id="faq-list-1" class="collapse show" data-parent=".faq-list">
                        <p>

                        </p>
                    </div>
                </li>

                <li data-aos="fade-up" data-aos-delay="100">
                    <i class="bx bx-run icon-help"></i> <a data-toggle="collapse" href="#faq-list-2" class="collapsed">Al
                        servicio de los pacientes ofrecemos vehículos para Transporte exclusivo de usuarios siendo la
                        tripulación personal capacitado que comprende y sabe sobre el manejo del paciente renal.<i
                            class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                    <div id="faq-list-2" class="collapse" data-parent=".faq-list">
                        <p>

                        </p>
                    </div>
                </li>

                <li data-aos="fade-up" data-aos-delay="200">
                    <i class="bx bx-run icon-help"></i> <a data-toggle="collapse" href="#faq-list-3"
                        class="collapsed">Refrigerio a los pacientes con dieta trazada por nuestra nutricionista.. <i
                            class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                    <div id="faq-list-3" class="collapse" data-parent=".faq-list">
                        <p>

                        </p>
                </li>

                <li data-aos="fade-up" data-aos-delay="200">
                    <i class="bx bx-run icon-help"></i> <a data-toggle="collapse" href="#faq-list-4"
                        class="collapsed">Confortables y amplios consultorios, sala de hemodiálisis, sala de espera, zonas
                        de esparcimiento, excelentes vías de acceso y en general moderno y funcional diseño arquitectónico.
                        <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                    <div id="faq-list-4" class="collapse" data-parent=".faq-list">
                        <p>

                        </p>
                </li>
                <li data-aos="fade-up" data-aos-delay="200">
                    <i class="bx bx-run icon-help"></i> <a data-toggle="collapse" href="#faq-list-7" class="collapsed">Por
                        ubicación estratégica ofrecemos atención integral del paciente renal ya que tenemos convenios
                        directos y siempre seguros para la atención de urgencias, hospitalización, cirugía, Unidad de
                        Cuidado Intensivo, toma de estudios de Imagenología y laboratorio Clínico.<i
                            class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                    <div id="faq-list-7" class="collapse" data-parent=".faq-list">
                        <p>

                        </p>
                </li>
            </ul>
        </div>

        </div>
    </section>
@endsection
