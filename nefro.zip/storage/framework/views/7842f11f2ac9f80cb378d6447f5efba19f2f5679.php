
<?php $__env->startSection('content'); ?>
    <br>
    <section>
        <div class="site-section pb-0">
            <div class="container">
                <div class="row mb-5 justify-content-center text-center">
                    <div class="col-lg-4 mb-5 text-center">
                    </div>
                    
 <div class="container">
    <div class="row mb-5 justify-content-center text-center">
        <div class="col-lg-4 mb-5 text-center">
        </div>
        <div class="container">
            <div class="section-title">
                <h2><span style="color: #737373;">BLOG DE NOTICIAS NOVEDADES </span> <span
                        style="color: #f57d00;">NEFROUROS</span> </span>
                </h2>
                <p>Nuestras noticias mas recientes <br> NEFROUROS le actualiza lo que sucede en nuestras
                    Unidades Renales </p>
            </div>
        </div>
    </div>
    <div class="row mb-5 justify-content-center text-center">
        <?php $__currentLoopData = $novedades_blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-4 col-md-6 mb-5 mb-lg-5">
            <div class="feature-1 border person text-center">
                <img src="<?php echo e($item->imagen_principal); ?>" width="160px" height="180px">
                <div class="feature-1-content">
                    <h5><?php echo e($item->nombre_noticia); ?></h5>
                    <span class="position mb-3 d-block" style="color: #f57d00;"><?php echo e($item->fecha_noticia); ?> </span>
                    <?php
                        $value = Str::limit($item->detalles_noticia, 120);
                    ?>
                    <p style="text-align: justify"><?php echo e($value); ?>  </p>
                    <a href="<?php echo e(route('Novedad.home',['id' =>$item->id_noticia, 'categoria'=>$item->categoria])); ?>" class="btn-get-started scrollto">ver mas + </a>
                </div>
            </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                         
        
    </div>
    <nav class="blog-pagination justify-content-center d-flex">
        <ul class="pagination">
            <ul class="pagination">
                <li class="page-item">
                    <?php echo e($covid_blog->links()); ?>

                </li>

            </ul>
        </ul>
    </nav>
</div>
                    <!--=================================================BLOG DE NOTICIAS pacientes =====================================================-->

                    <div class="container">
                        <div class="row mb-5 justify-content-center text-center">
                            <div class="col-lg-4 mb-5 text-center">
                            </div>
                            <div class="container">
                                <div class="section-title">
                                    <h2><span style="color: #737373;">BLOG DE NOTICIAS COMPAÑERO Y PACIENTE DEL MES </span> <span
                                            style="color: #f57d00;">NEFROUROS</span> </span>
                                    </h2>
                                    <p>Nuestras noticias mas recientes <br> NEFROUROS le actualiza lo que sucede en nuestras
                                        Unidades Renales </p>
                                </div>
                            </div>
                        </div>
                        <div class="row mb-5 justify-content-center text-center">
                            <?php $__currentLoopData = $pacientes_blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-4 col-md-6 mb-5 mb-lg-5">
                                <div class="feature-1 border person text-center">
                                    <img src="<?php echo e($item->imagen_principal); ?>" width="348px" height="180px">
                                    <div class="feature-1-content">
                                        <h5><?php echo e($item->nombre_noticia); ?></h5>
                                        <span class="position mb-3 d-block" style="color: #f57d00;"><?php echo e($item->fecha_noticia); ?> </span>
                                        <?php
                                            $value = Str::limit($item->detalles_noticia, 120);
                                        ?>
                                        <p style="text-align: justify"><?php echo e($value); ?>  </p>
                                        <a href="<?php echo e(route('blogdetalles.home',['id' =>$item->id_noticia, 'categoria'=>$item->categoria])); ?>" class="btn-get-started scrollto">ver mas + </a>
                                    </div>
                                </div>
                            </div>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                         
                            
                        </div>
                        <nav class="blog-pagination justify-content-center d-flex">
                            <ul class="pagination">
                                <ul class="pagination">
                                    <li class="page-item">
                                        <?php echo e($pacientes_blog->links()); ?>

                                    </li>
                
                                </ul>
                            </ul>
                        </nav>
                    </div>
 
                    <!--=================================================BLOG DE NOTICIAS SALUDABLES=====================================================-->
                    <div class="container">
                        <div class="row mb-5 justify-content-center text-center">
                            <div class="col-lg-4 mb-5 text-center">
                            </div>
                            <div class="container">
                                <div class="section-title">
                                    <h2><span style="color: #737373;">BLOG DE NOTICIAS SALUDABLES </span> <span
                                            style="color: #f57d00;">NEFROUROS</span> </span>
                                    </h2>
                                    <p>Nuestras noticias mas recientes <br> NEFROUROS le actualiza lo que sucede en nuestras
                                        Unidades Renales </p>
                                </div>
                            </div>
                        </div>
                        <div class="row mb-5 justify-content-center text-center">
                            <?php $__currentLoopData = $saludables_blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-4 col-md-6 mb-5 mb-lg-5">
                                <div class="feature-1 border person text-center">
                                    <img src="<?php echo e($item->imagen_principal); ?>" width="160px" height="180px">
                                    <div class="feature-1-content">
                                        <h5><?php echo e($item->nombre_noticia); ?></h5>
                                        <span class="position mb-3 d-block" style="color: #f57d00;"><?php echo e($item->fecha_noticia); ?> </span>
                                        <?php
                                            $value = Str::limit($item->detalles_noticia, 120);
                                        ?>
                                        <p style="text-align: justify"><?php echo e($value); ?>  </p>
                                        <a href="<?php echo e(route('blogdetalles.home',['id' =>$item->id_noticia, 'categoria'=>$item->categoria])); ?>" class="btn-get-started scrollto">ver mas + </a>
                                    </div>
                                </div>
                            </div>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                         
                            
                        </div>
                        <nav class="blog-pagination justify-content-center d-flex">
                            <ul class="pagination">
                                <ul class="pagination">
                                    <li class="page-item">
                                        <?php echo e($saludables_blog->links()); ?>

                                    </li>
                
                                </ul>
                            </ul>
                        </nav>
                    </div>
                    <!--=================================================BLOG DE NOTICIAS covid=====================================================-->

                    <div class="container">
                        <div class="row mb-5 justify-content-center text-center">
                            <div class="col-lg-4 mb-5 text-center">
                            </div>
                            <div class="container">
                                <div class="section-title">
                                    <h2><span style="color: #737373;">BLOG DE NOTICIAS COVID-19 </span> <span
                                            style="color: #f57d00;">NEFROUROS</span> </span>
                                    </h2>
                                    <p>Nuestras noticias mas recientes <br> NEFROUROS le actualiza lo que sucede en nuestras
                                        Unidades Renales </p>
                                </div>
                            </div>
                        </div>
                        <div class="row mb-5 justify-content-center text-center">
                            <?php $__currentLoopData = $covid_blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-4 col-md-6 mb-5 mb-lg-5">
                                <div class="feature-1 border person text-center">
                                    <img src="<?php echo e($item->imagen_principal); ?>" width="160px" height="180px">
                                    <div class="feature-1-content">
                                        <h5><?php echo e($item->nombre_noticia); ?></h5>
                                        <span class="position mb-3 d-block" style="color: #f57d00;"><?php echo e($item->fecha_noticia); ?> </span>
                                        <?php
                                            $value = Str::limit($item->detalles_noticia, 120);
                                        ?>
                                        <p style="text-align: justify"><?php echo e($value); ?>  </p>
                                        <a href="<?php echo e(route('blogdetalles.home',['id' =>$item->id_noticia, 'categoria'=>$item->categoria])); ?>" class="btn-get-started scrollto">ver mas + </a>
                                    </div>
                                </div>
                            </div>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                         
                            
                        </div>
                        <nav class="blog-pagination justify-content-center d-flex">
                            <ul class="pagination">
                                <ul class="pagination">
                                    <li class="page-item">
                                        <?php echo e($covid_blog->links()); ?>

                                    </li>
                
                                </ul>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </section>
   
</div>
</div>
</div>
</section>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layauts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nefro\resources\views/Blognoticias/index.blade.php ENDPATH**/ ?>