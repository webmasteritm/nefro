<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>NEFROUROS - Servimos con el alma</title>
    <meta content="" name="descriptison">
    <meta content="" name="keywords">
    <!-- Favicons -->
    <link href="assets/img/favicon.png" rel="icon">
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">
    <!-- Google Fonts -->
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
        rel="stylesheet">
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
    <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
    <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/flaticon.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <?php echo $__env->yieldContent('css'); ?>

</head>

<body>
    <!-- ======= Top Bar ======= -->
    <div id="topbar" class="d-none d-lg-flex align-items-center fixed-top">
        <div class="container d-flex">
            <div class="contact-info mr-auto">
            </div>
            <div class="social-links">
                <a href="https://www.facebook.com/pages/Nefrouros-Unidad-Renal/198206136885995" target="_blank"
                    class="facebook"><i class="icofont-facebook"></i></a>
                <a href="https://www.instagram.com/nefrouros/" target="_blank" class="instagram"><i
                        class="icofont-instagram"></i></a>
            </div>
        </div>
    </div>
    
    <div class="pre-loader">
        <div class="pre-loader-box">
            <div class="loader-logo">
                <div class="pre-loader-inner position-relative">
                    <div class="preloader-circle"></div>
                    <div class="pre-loader-img">
                        <img src="assets/img/favicon.png" alt="Iniciando Nefrouros.net">
                    </div>
                </div>
            </div>
            <div class='loader-progress' id="progress_div">
                <div class='bar' id='bar1'></div>
            </div>
            <div class='percent' id='percent1'>0%</div>
            <div class="loading-text">
                Cargando Nefrouros.net
            </div>
        </div>
    </div>
    <!-- ======= Header ======= -->
    <header id="header" class="fixed-top">
        <div class="container d-flex align-items-center">
            <img src="assets/img/05.png" alt="" class="logo mr-auto">
            <nav class="nav-menu d-none d-lg-block">
                <ul>
                    <li class="active"><a href="<?php echo e(route('home.inicio')); ?>">Inicio</a></li>
                    <li class="drop-down"><a href="#">Organización</a>
                        <ul>
                            <!--<li><a href="nuestro-equipo.html">Nuestro Equipo</a></li>-->
                            <li><a href="<?php echo e(route('home.servicios')); ?>">Servicios</a></li>
                            <li><a href="<?php echo e(route('home.plataformaEstrategica')); ?>">Plataforma Estratégica</a></li>
                            <li><a href="<?php echo e(route('home.codigosdeEtica')); ?>">Código De Ética</a></li>
                            <li><a href="<?php echo e(route('home.estadosFinancieros')); ?>">Estados Financieros </a></li>
                            <li><a href="<?php echo e(route('home.Sarlaft')); ?>">SARLAFT</a></li>
                            <li class="drop-down"><a href="#">COPASST</a>
                                <ul>
                                    <li><a href="<?php echo e(route('copasst.nefrourosFundacion')); ?>">Fundación Nefrouros</a></li>
                                    <li><a href="<?php echo e(route('copasst.nefroServicios')); ?>">Nefroservicios Sas</a></li>
                                    <li><a href="<?php echo e(route('copasst.sesSalud')); ?>">Ses Salud – Yopal</a></li>
                                    <li><a href="<?php echo e(route('copasst.Garzon')); ?>">Nefrouros MOM – Garzon</a></li>
                                    <li><a href="<?php echo e(route('copasst.Pitalito')); ?>">Nefrouros MOM – Pitalito</a></li>
                                    <li><a href="<?php echo e(route('copasst.Rionegro')); ?>">Nefrouros MOM – Rionegro</a></li>
                                    <li><a href="<?php echo e(route('copasst.Envigado')); ?>">Nefrouros MOM - Envigado</a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li class="drop-down"><a href="#">Pacientes</a>
                        <ul>
                            <li><a href="<?php echo e(route('home.Calendario')); ?>">Calendario Actividades</a></li>
                            <li><a href="<?php echo e(route('home.DerechosyDeberes')); ?>">Derechos Y Deberes</a></li>
                            <li><a href="<?php echo e(route('home.ValoreAgregados')); ?>">Valores Agregados</a></li>
                            <li><a href="<?php echo e(route('home.actividadesPacientes')); ?>">Actividades Pacientes</a></li>
                        </ul>
                    <li class="drop-down"><a href="#">Sedes</a>
                        <ul>
                            <li><a href="<?php echo e(route('sedes.home',['id'=>'1','sede'=>'Neiva'])); ?>">Sede Neiva</a></li>
                            <li><a href="<?php echo e(route('sedes.home',['id'=>'2','sede'=>'Pitalito'])); ?>">Sede Pitalito</a></li>
                            <li><a href="<?php echo e(route('sedes.home',['id'=>'3','sede'=>'Ibague'])); ?>">Sede Ibagué</a></li>
                            <li><a href="<?php echo e(route('sedes.home',['id'=>'4','sede'=>'Duitama'])); ?>">Sede Duitama</a></li>
                            <li><a href="<?php echo e(route('sedes.home',['id'=>'5','sede'=>'Tunja'])); ?>">Sede Tunja</a></li>
                            <li><a href="<?php echo e(route('sedes.home',['id'=>'6','sede'=>'Monteria'])); ?>">Sede Montería</a></li>
                            <li><a href="<?php echo e(route('sedes.home',['id'=>'7','sede'=>'Yopal'])); ?>">Sede Yopal</a></li>
                            <li><a href="<?php echo e(route('sedes.home',['id'=>'8','sede'=>'Barrancabermeja'])); ?>">Sede Barrancabermeja</a></li>
                            <li><a href="<?php echo e(route('sedes.home',['id'=>'9','sede'=>'Envigado'])); ?>">Sede Envigado</a></li>
                            <li><a href="<?php echo e(route('sedes.home',['id'=>'10','sede'=>'Garzon'])); ?>">Sede Garzón</a></li>
                            <li><a href="<?php echo e(route('sedes.home',['id'=>'11','sede'=>'Medellin'])); ?>">Sede Medellín</a></li>
                            <li><a href="<?php echo e(route('sedes.home',['id'=>'12','sede'=>'Barranquilla '])); ?>">Sede Barranquilla </a></li>
                            <li><a href="<?php echo e(route('sedes.home',['id'=>'13','sede'=>'Rionegro'])); ?>">Sede Rionegro </a></li>
                            <li><a href="<?php echo e(route('sedes.home',['id'=>'14','sede'=>'Apartado'])); ?>">Sede Apartadó </a></li>
                            <li><a href="<?php echo e(route('sedes.home',['id'=>'15','sede'=>'Lorica'])); ?>">Sede Lorica </a></li>
                            <li><a href="<?php echo e(route('sedes.home',['id'=>'16','sede'=>'Puertoasis'])); ?>">Sede Puerto Asís </a></li>
                        </ul>
                    </li>
                    <li><a href="<?php echo e(route('blog.home')); ?>">Noticias</a></li>
                    <li><a href="<?php echo e(route('prefuntasFrecuentes.home')); ?>">Preguntas Frecuentes</a></li>
                </ul>
        </div>
    </header>
    <br><br><br><br><br>
    

    


    <?php echo $__env->yieldContent('content'); ?>


    <footer id="footer">

        <div class="footer-top">
            <div class="container">
                <div class="carousel slide carousel-fade">
                    <div class="container d-md-flex py-4">

                        <div class="mr-md-auto text-center text-md-left">
                            <div class="copyright">
                                &copy; Copyright <strong><span>IT Management Zomac S.A.S</span></strong>. All Rights
                                Reserved
                            </div>
                            <div class="credits">
                                Desarrollado por <a href="https://itmsas.net/">IT Management</a>
                            </div>
                        </div>
                        <div class="social-links text-center text-md-right pt-3 pt-md-0">
                            <a href="https://www.facebook.com/pages/Nefrouros-Unidad-Renal/198206136885995"
                                target="_blank" class="facebook"><i class="bx bxl-facebook"></i></a>
                            <a href="https://www.instagram.com/nefrouros/" target="_blank" class="instagram"><i
                                    class="bx bxl-instagram"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- End Footer -->
    <div id="preloader"></div>
    <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/vendor/venobox/venobox.min.js"></script>
    <script src="assets/vendor/counterup/counterup.min.js"></script>
    <script src="assets/js/main.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <?php echo $__env->yieldContent('copasst-script'); ?>
    <?php echo $__env->yieldContent('js'); ?>

</body>

</html>
<?php /**PATH C:\laragon\www\nefro\resources\views////layauts/plantilla.blade.php ENDPATH**/ ?>