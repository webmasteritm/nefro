@extends('layauts.plantilla')
@section('content')
    <section id="hero">
        <div id="heroCarousel" class="carousel slide carousel-fade" data-ride="carousel">

            <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>

            <div class="carousel-inner" role="listbox">
                <!-- Slide 1 -->
                <div class="carousel-item active" style="background-image: url(../assets/img/sedes/UR-neiva/_MG_1099.jpg)">
                    <div class="container">
                        <h2><span style="color: #F57D00;">NEFROUROS</span> <span style="color: #737373;">SEDE
                                BARRANQUILLA</span></h2>
                                <a href="{{ route('citas.home') }}" class="btn-get-started scrollto">Citas en linea</a>

                    </div>
                </div>
                <!-- Slide 2 -->
                <div class="carousel-item"
                    style="background-image: url(../assets/img/sedes/UR-neiva/Fachada---NEFROUROS.jpg)">
                </div>
                <!-- Slide 3 -->
                <div class="carousel-item" style="background-image: url(../assets/img/sedes/UR-neiva/_MG_1026-HDR.jpg)">
                </div>
            </div>

            <a class="carousel-control-prev" href="#heroCarousel" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon icofont-simple-left" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>

            <a class="carousel-control-next" href="#heroCarousel" role="button" data-slide="next">
                <span class="carousel-control-next-icon icofont-simple-right" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>

        </div>
    </section>
    <!-- End Hero -->
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <section id="contact" class="contact">

        <div class="container">
            <div class="section-title">
                <h2><span style="color: #F57D00;">NEFROUROS</span> <span style="color: #737373;">SEDE BARRANQUILLA</span>
                </h2>
                <p>Puede contactar nuestra unidad renal en la ciudad de barranquilla ,diligencie el formulario y verifique
                    que sus datos esten correctos. </p>
            </div>
        </div>
        <div>
            <iframe style="border:0; width: 100%; height: 350px;"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3916.46976147303!2d-74.82118228469736!3d11.003337992167777!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8ef42da9aeb50fcf%3A0xd21f489cc7782b08!2sCra.%2049c%20%2384-57%2C%20Barranquilla%2C%20Atl%C3%A1ntico!5e0!3m2!1ses!2sco!4v1602009372108!5m2!1ses!2sco"
                width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false"
                tabindex="0"></iframe>
        </div>


        <div class="container">
            <div class="row mt-5">
                <div class="col-lg-4">
                    <div class="info">
                        <div class="address">
                            <i class="icofont-google-map"></i>
                            <h4>Ubicación::</h4>
                            <p>cra 49c # 84 - 57 barrio san vicente Barranquilla,Atlantico
                            </p>
                        </div>

                        <div class="email">
                            <i class="icofont-envelope"></i>
                            <h4>Email:</h4>
                            <p>gerenciabarranquilla@nefrouros.net</p>
                        </div>

                        <div class="phone">
                            <i class="icofont-phone"></i>
                            <h4>Teléfonos:</h4>
                            <p>(5) 3311596 - 3164413686</p>
                        </div>

                    </div>

                </div>
                <x-formulario-contacto></x-formulario-contacto>

            </div>
    
        </div>
    </section>  
    
    @endsection
    @section('js') 
    
    {{-- Componente del script envio --}}
    <x-formulario-script></x-formulario-script>
    
    @endsection