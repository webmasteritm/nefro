@extends('../layauts.plantilla')
@section('content')
<br><br>
<br><br>

<form method="post" action="{{ route('update.calendario') }}" class="php-email-form alerta">
    @csrf
    <div class="form-row">
        <div class="form-group col-md-6">
            <label for="nombre">actividad</label>
            <input type="text" class="form-control" placeholder="Nombre de la noticia"
                name='actividad' id="actividad" >
        </div>
        <div class="form-group col-md-6">
            <label for="tetx">Fecha </label>
            <input type="text" class="form-control" placeholder="30 de noviembre de 1999"
                name="fecha" id="fecha">
        </div>
        <div class="form-group col-md-6">
            <label for="detalles">detalles</label>
                <textarea class="form-control" id="detalles" name="detalles"
                placeholder="Describa la noticia" ></textarea>
        </div>


        <div class="form-group col-md-6">
            <label for="idcalendario">MES:</label>
            <select id="idcalendario" class="form-control" name='idcalendario' id="idcalendario" >
                <option value="">Seleccionar</option>
                @foreach ($meses as $mes)
                <option value="{{ $mes->id }}">{{ $mes->meses }}</option>                    
                @endforeach
                
            </select>
        </div>

        <div class="form-group col-md-6">
            <button type="submit" class="btn btn-success" name='btn_send'>Enviar </button>
        </div>
    </div>
</form>    
@endsection