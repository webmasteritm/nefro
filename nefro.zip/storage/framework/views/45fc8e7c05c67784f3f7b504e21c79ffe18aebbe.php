<a href="https://nefrouros.net">
    <img src="https://nefrouros.net/assets/img/favicon.png" title="Amatista"style="width:100px;">
</a>
<?php /**PATH C:\laragon\www\nefro\vendor\laravel\jetstream\src/../resources/views/components/authentication-card-logo.blade.php ENDPATH**/ ?>