@extends('layauts.plantilla')
@section('content')
    <!-- business_expert_area_start  -->
    <section>
        <div class="container">
            <div class="section-title">
                <h2><span style="color: #737373;">NUESTRA </span> <span style="color: #f57d00;">PLATAFORMA ESTRATEGICA </span></h2>
                <p></p>
            </div>
        </div>
        <div class="business_expert_area">
            <div class="business_tabs_area">

                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            <ul class="nav" id="myTab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab"
                                        aria-controls="home" aria-selected="true">
                                        <h4><span style="color: #F57D00;">NUESTRA</span> <span
                                                style="color: #737373;">MISIÓN</span></h4>
                                    </a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab"
                                        aria-controls="profile" aria-selected="false">
                                        <h4><span style="color: #F57D00;">NUESTRA</span> <span
                                                style="color: #737373;">VISIÓN</span></h4>
                                    </a>
                                    </a>
                                </li>


                                <li class="nav-item">
                                    <a class="nav-link" id="contact-tab" data-toggle="tab" href="#contact" role="tab"
                                        aria-controls="contact" aria-selected="false">
                                        <h4><span style="color: #F57D00;">NUESTROS</span> <span
                                                style="color: #737373;">VALORES</span></h4>
                                    </a>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="contact-tab" data-toggle="tab" href="#HIMNO" role="tab"
                                        aria-controls="HIMNO" aria-selected="false">
                                        <h4><span style="color: #F57D00;">NUESTRO</span> <span
                                                style="color: #737373;">HIMNO</span></h4>
                                    </a>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>

                </div>
            </div>
            <div class="container">
                <div class="border_bottom">
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">

                            <div class="row align-items-center">
                                <div class="col-xl-6 col-md-6">
                                    <div class="business_info">
                                        <div class="icon">
                                            <i class="icofont-scroll-long-down"></i>
                                        </div>
                                        <h3>MISIÓN</h3>
                                        <p>
                                        <div class="icon">
                                        </div>
                                        Brindamos atención integral a los pacientes con enfermedades precursoras de daño
                                        renal o con enfermedad renal establecida, con alta calidad científica de la mano de
                                        la más alta calidez humana.
                                        </p>
                                    </div>
                                </div>
                                <div class="col-xl-6 col-md-6">
                                    <div class="business_thumb">
                                        <img src="assets/img/sedes/UR-neiva/_MG_1099.jpg" alt="">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                            <div class="row align-items-center">
                                <div class="col-xl-6 col-md-6">
                                    <div class="business_info">
                                        <div class="icon">
                                            <i class="icofont-scroll-long-down"></i>
                                        </div>
                                        <h3>VISIÓN</h3>
                                        <p>
                                            En el 2022, ser reconocidos a nivel nacional por nuestra excelencia en la
                                            atención integral de nuestros usuarios.
                                        </p>
                                    </div>
                                </div>
                                <div class="col-xl-6 col-md-6">
                                    <div class="business_thumb">
                                        <img src="assets/img/sedes/UR-neiva/slider3.jpg" alt="">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                            <div class="row align-items-center">
                                <div class="col-xl-6 col-md-6">
                                    <div class="business_info">
                                        <div class="icon">
                                            <i class="icofont-scroll-long-down"></i>
                                        </div>
                                        <h3>VALORES</h3>
                                        <p class="user-select-all"><b>RESPONSABILIDAD:</b> Hacemos lo que debemos según lo
                                            establecido.</p>
                                        <p class="user-select-all"><b>HONESTIDAD:</b> Actuamos coherentemente con nuestros
                                            valores y principios.</p>
                                        <p class="user-select-all"><b>RESPETO:</b> Reconocemos y toleramos las creencias,
                                            actuaciones, sentimientos y motivos de las personas.</p>
                                        <p class="user-select-all"><b>COMPROMISO:</b> Cuando cumple con sus obligaciones,
                                            con aquello que se ha propuesto o que le ha sido encomendado. </p>


                                    </div>
                                </div>
                                <div class="col-xl-6 col-md-6">
                                    <div class="business_info">
                                        <p class="user-select-all"><b>EQUIPO HUMANO: </b> Personal altamente cualificado,
                                            que le asesorara sobre nuestros productos adecuándose a las distintas
                                            necesidades según el tipo de cliente.</p>
                                        <p class="user-select-all"><b>FE:</b> Es la seguridad o confianza en una persona,
                                            cosa, opinión, doctrinas o enseñanzas de una religión.</p>
                                        <p class="user-select-all"><b>CALIDEZ HUMANA:</b> Es el cariño, amabilidad y afecto
                                            que muestran las personas por los demás. Calidez significa calor, lo cual se
                                            traduce en un ambiente alegre y cordial en las relaciones interpersonales.</p>
                                        <p class="user-select-all"><b>CALIDAD CIENTÍFICA:</b> Que cuenta con los mejores
                                            recursos tecnológicos en el mercado para la prestación de sus servicios.</p>
                                        <p class="user-select-all"><b>AMOR:</b>Conjunto de comportamientos y actitudes que
                                            resultan desinteresados e incondicionales, y que se manifiestan entre seres que
                                            tienen la capacidad de desarrollar inteligencia emocional. </p>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="HIMNO" role="tabpanel" aria-labelledby="HIMNO-tab">
                            <section id="about" class="about">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-xl-5 col-lg-6 video-box d-flex justify-content-center align-items-stretch"
                                            style="background-image: url(assets/img/slide/slider3.jpg)">
                                            <a href="https://youtu.be/CWiHb4dqjIY" class="venobox play-btn mb-4"
                                                data-vbtype="video" data-autoplay="true"></a>
                                        </div>

                                        <div
                                            class="col-xl-7 col-lg-6 icon-boxes d-flex flex-column align-items-stretch justify-content-center py-5 px-lg-5">
                                            <div class="container">
                                                <div class="section-title">
                                                    <h2><span style="color: #f57d00"> HIMNO NEFROUROS</span> <span
                                                            style="color: #737373;">UNIDAD RENAL</span> </span>
                                                    </h2>


                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
    </section>

@endsection
