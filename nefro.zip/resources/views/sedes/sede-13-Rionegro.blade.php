@extends('layauts.plantilla')
@section('content')
<section id="hero">
    <div id="heroCarousel" class="carousel slide carousel-fade" data-ride="carousel">

        <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>

        <div class="carousel-inner" role="listbox">
            <!-- Slide 1 -->
            <div class="carousel-item active" style="background-image: url(../assets/img/sedes/UR-rionegro/IMG_8669.jpg)">
                <div class="container">
                    <h2><span style="color: #F57D00;">NEFROUROS</span> <span style="color: #737373;">SEDE RIONEGRO </span></h2>
                    <a href="{{ route('citas.home') }}" class="btn-get-started scrollto">Citas en linea</a>

                </div>
            </div>
            <!-- Slide 2 -->
            <div class="carousel-item" style="background-image: url(../assets/img/sedes/UR-rionegro/IMG_8672.jpg)">
            </div>
            <!-- Slide 3 -->
            <div class="carousel-item" style="background-image: url(../assets/img/sedes/UR-rionegro/IMG_E8726.jpg)">
            </div>
        </div>
        <a class="carousel-control-prev" href="#heroCarousel" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon icofont-simple-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>

        <a class="carousel-control-next" href="#heroCarousel" role="button" data-slide="next">
            <span class="carousel-control-next-icon icofont-simple-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>

    </div>
</section>
<!-- End Hero -->

<br></br>
<br></br>
<br></br>
<br></br>
<br></br>
<section id="contact" class="contact">

    <div class="container">
        <div class="section-title">
            <h2><span style="color: #F57D00;">NEFROUROS</span> <span style="color: #737373;">SEDE RIONEGRO</span></h2>
            <p>Puede contactar nuestra unidad renal en la ciudad de Rionegro, diligencie el formulario y verifique que sus datos esten correctos. </p>
        </div>
    </div>
    <div>
    </div>


    <div class="container">
        <div class="row mt-5">


            <div class="col-lg-4">
                <div class="info">
                    <div class="address">
                        <i class="icofont-google-map"></i>
                        <h4>Ubicación:</h4>
                        <p> 55A No. 35-227 Edificio City Medica – TORRE 2 – locales 322 y 323
                            <p>Rionegro</p>
                        </p>
                    </div>
                    <div class="email">
                        <i class="icofont-envelope"></i>
                        <h4>Email:</h4>
                        <p>gerenciarionegro@nefrouros.net </p>
                    </div>

                    <div class="phone">
                        <i class="icofont-phone"></i>
                        <h4>Teléfonos:</h4>
                        <p>5579702 – 3008645910</p>
                    </div>

                </div>

            </div>
            <x-formulario-contacto></x-formulario-contacto>

        </div>

    </div>
</section>  

@endsection
@section('js') 

{{-- Componente del script envio --}}
<x-formulario-script></x-formulario-script>

@endsection