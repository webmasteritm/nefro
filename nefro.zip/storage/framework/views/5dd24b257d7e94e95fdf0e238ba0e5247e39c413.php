
<?php $__env->startSection('content'); ?>
  
    <section id="gallery" class="gallery">

        <div class="container">

            <div class="container-fluid">
                <div class="row no-gutters">
                    <h2 style="align-items: center"><span style="color: #737373;">Galeria de actividades: Nuestros pacientes en la sede:
                        </span> <span style="color: #f57d00;"><?php echo e($sede); ?></span>
                        </span>
                    </h2>
                    <nav class="navegacion">
                        <ul class="menu">
                            <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sede): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a
                                        href="<?php echo e(route('actividades.pacientes', ['id' => $sede->id, 'sede' => $sede->sede])); ?>"><?php echo e($sede->sede); ?></a>
                                </li>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </nav>
                </div 
                <div class="container">
                <div class="container-fluid">
                    <div class="row no-gutters">

                        <?php $__currentLoopData = $actividadesimg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-3 col-md-4">
                                <div class="gallery-item">
                                    <a href="<?php echo e($item->url); ?>" class="venobox" data-gall="gallery-item">
                                        <img src="<?php echo e($item->url); ?>" alt="" class="img-fluid">
                                        <div class="experts_name text-center">
                                            <h5><?php echo e($item->nombre_actividad); ?></h5>
                                            <span><?php echo e($item->descripcion_actividad); ?></span><br>
                                            <span><?php echo e($item->sede); ?></span>
                                        </div>
                                    </a>


                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>

        <nav class="blog-pagination justify-content-center d-flex">
            <ul class="pagination">
                <ul class="pagination">
                    <li class="page-item">
                        <?php echo e($actividadesimg->links()); ?>

                    </li>

                </ul>
            </ul>
        </nav>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layauts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nefro\resources\views/GaleriaActividades/todaslasactividades.blade.php ENDPATH**/ ?>