
<?php $__env->startSection('content'); ?>
<br><br>
<br><br>

<form method="post" action="<?php echo e(route('update.blog')); ?>" enctype="multipart/form-data" class="php-email-form alerta">
    <?php echo csrf_field(); ?>
    <div class="form-row">
        <div class="form-group col-md-6">
            <label for="nombre">Nombre</label>
            <input type="text" class="form-control" placeholder="Nombre de la noticia"
                name='nombre' id="nombre" >
        </div>
        <div class="form-group col-md-6">
            <label for="tetx">Fecha </label>
            <input type="text" class="form-control" placeholder="30 de noviembre de 1999"
                name="fecha" id="fecha">
        </div>
        <div class="form-group col-md-6">
            <label for="detalles">detalles</label>
                <textarea class="form-control" id="detalles" name="detalles"
                placeholder="Describa la noticia" ></textarea>
        </div>


        <div class="form-group col-md-6">
            <label for="categotria">Categoria:</label>
            <select id="categotria" class="form-control" name='categoria' id="categotria" >
                <option value="null">Seleccionar</option>
                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->categoria); ?></option>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </select>
        </div>
        <div class="form-group col-md-6">
            <label for="imagen_princial">Imagen principal</label>
       <input type="file" name="imagen_princial[]" id="imagen_princial[]"accept="image/*">
        </div>
        <div class="form-group col-md-6">
            <label for="imagenes_noticias">Imagenes Noticias</label>
       <input type="file" multiple name="imagenes_noticias[]" id="imagenes_noticias[]" accept="image/*">
        </div>
        <div class="form-group col-md-6">
            <button type="submit" class="btn btn-success" name='btn_send'>Enviar </button>
        </div>
    </div>
</form>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layauts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nefrouros.net\resources\views/Blognoticias/subir-noticia.blade.php ENDPATH**/ ?>