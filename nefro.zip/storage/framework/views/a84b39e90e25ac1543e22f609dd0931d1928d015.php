
<?php $__env->startSection('title', 'Nefrouros|Editar-Actividades'); ?>
<?php $__env->startSection('content'); ?>
<style>
.dirty-dash {
}

.prueba {
    background-color: #f57d00;
}
.gal {
    width: 150px;
    height: 150px;
    float: left;
    margin: 1%;
}
.btn-outline-danger {
    background-color: transparent;
    border-radius: 80%;
    border-color: transparent;
    margin-left: 35%;
}
.bi-trash {
    color: black;
    width: -150px;
    
}
</style>
    <link href="assets/img/favicon.png" rel="icon">
    <link rel="stylesheet" href="/assets/css/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
    <section class="container-fluid" style="background-color: white; height:900px;">
        <header>
            <div class="container-fluid" style="background-color: white">
                <img src="https://nefrouros.net/assets/img/05.png">

            </div>
        </header>
        <br>

        <hr class="prueba">
        <div id="contact" class="contact">

            <form action="<?php echo e(route('actualizar.actividad', ['id' => $actividad->id])); ?>" enctype="multipart/form-data"
                method="POST">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>

                <div class="row">




                    <div class="col-sm-12">
                        <div class="form-group">
                            <strong>Imagen:</strong>
                            <input type="file" multiple name="imagen_actividad[]" id="imagen_actividad[]" accept="image/*">
                        </div>

                    </div>

                    <div class="col-sm-12">
                        <div class="form-group">
                            <strong>Selecione la imagen principal:</strong>
                            <input type="file" name="imagen_principal[]" id="imagen_principal[]" accept="image/*">
                        </div>

                    </div>

                    <div class="col-sm-12">
                        <div class="form-group">
                            <strong>sede:</strong>
                            <select class="custom-select" id="sede" name="sede" value="dasdsa">
                                <option selected><?php echo e($actividad->sede_id); ?></option>
                                <?php $__currentLoopData = $sede; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->sede); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <div class="form-group">
                            <strong>actividad:</strong>
                            <input type="text" name="actividad" class="form-control"
                                value="<?php echo e($actividad->nombre_actividad); ?>">

                        </div>
                    </div>


                    <div class="col-sm-12">
                        <div class="form-group">
                            <strong>descripcion:</strong>
                            <input type="text" name="descripcion" class="form-control"
                                value="<?php echo e($actividad->descripcion_actividad); ?>">
                        </div>
                    </div>






                    <div class="col-sm-12 text-center">
                        <a href="javascript: history.go(-1)" class="btn btn-success">CANCELAR</a>
                        <button type="submit" class="btn btn-primary">ENVIAR</button>
                    </div>
                </div>
            </form>
            <div class="row">
                <div class="col-sm-12">
                    <h4>Imagenes Actividad</h4>
                    <?php $__currentLoopData = $imagen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                        <div>

                            <div class="dirty-dash">
                                <div class="gal">
                                    <div class="card">

                                        <form action="<?php echo e(route('delete.imagen', ['id' => $k->id])); ?>" method="POST">
                                            <img src="<?php echo e($k->url); ?>" alt="" class="img-fluid">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('put'); ?>
                                            <button type="submit" class="btn btn-outline-danger"><i
                                                    class="bi bi-trash"></i></button>

                                        </form>

                                    </div>

                                </div>
                            </div>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
         

        </div>
        

    </section>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nefro\resources\views/galeria/editar-actividad.blade.php ENDPATH**/ ?>