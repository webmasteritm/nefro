@extends('layauts.plantilla')

@section('content')

    <section id="services" class="services">
        <div class="container">
            <div class="section-title">
                <h2><span style="color: #737373;">NUESTROS  </span> <span style="color: #f57d00;">SERVICIOS </span></h2>
                <p></p>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
                    <div class="icon-box">
                        <div class="icon"><i class="icofont-doctor"></i></div>
                        <h4><a href="#" data-toggle="modal" data-target="#servicio1">Consulta de nefrología pediátrica y
                                nefrología adultos</a></h4>
                        <p>
                            <!--mensajes de texto-->
                        </p>
                    </div>
                </div>
                <!-- Modal 1 -->
                <div class="modal fade" id="servicio1" data-backdrop="static" data-keyboard="false" tabindex="-1"
                    aria-labelledby="staticBackdropLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title" id="servicio1">Consulta de nefrología pediátrica y nefrología
                                    adultos
                                </h4>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <p style="text-align: justify;">Contamos con médicos especialistas expertos en nefrología y
                                    nefrología pediátrica que realizan un abordaje integral de la enfermedad renal:
                                    prevención renal, intervención de factores de riesgo, tamizaje para enfermedades
                                    del riñón, diagnósticos oportunos de enfermedad renal, abordaje integral de la
                                    enfermedad renal y sus complicaciones, preparación para terapias renales sustitutivas.
                                    Estos servicios de consulta se ofrecen en la modalidad
                                    presencial (garantizando las mejores prácticas de bioseguridad), virtual o asistencia de
                                    las atenciones hospitalarias (modalidad conocida como interconsulta o consulta
                                    extramural). </p>
                            </div>
                            <div class="modal-footer">

                                <button type="button" class="btn btn-secondary " data-dismiss="modal">Cerrar</button>


                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-md-0">
                    <div class="icon-box">
                        <div class="icon"><i class="icofont-doctor"></i></div>
                        <h4><a href="#" data-toggle="modal" data-target="#servicio2">Programa de protección renal “VIDA
                                NEFROUROS”</a></h4>
                        <p>
                            <!--mensajes de texto-->
                        </p>
                    </div>
                </div>
                <!-- Modal 2-->
                <div class="modal fade" id="servicio2" data-backdrop="static" data-keyboard="false" tabindex="-1"
                    aria-labelledby="servicio2" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title" id="servicio2">Programa de protección renal “VIDA NEFROUROS”
                                </h4>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <p style="text-align: justify;">Nuestro programa de protección renal “VIDA NEFROUROS” tiene
                                    como propósito principal retardar la progresión de la enfermedad renal evitando de esta
                                    manera el ingreso temprano a diálisis y la aparición de complicaciones
                                    e incluso en etapas tempranas de la enfermedad renal, revertirla. Nuestro programa “VIDA
                                    NEFROUROS” cuenta con profesionales expertos en nefrología y programas de apoyo como
                                    actores fundamentales de la intervención
                                    del paciente que conciencia sobre el mantenimiento de la salud y el bienestar y el
                                    fortalecimiento de elementos de autocuidado.</p>
                            </div>
                            <div class="modal-footer">
                                <center><button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                                </center>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-lg-0">
                    <div class="icon-box">
                        <div class="icon"><i class="icofont-doctor"></i></div>
                        <h4><a href="#" data-toggle="modal" data-target="#servicio3">Hemodiálisis de alta eficiencia
                                ambulatoria y
                                extramural</a></h4>
                        <p>
                            <!--mensajes de texto-->
                        </p>
                    </div>
                </div>
                <!-- Modal 3-->
                <div class="modal fade" id="servicio3" data-backdrop="static" data-keyboard="false" tabindex="-1"
                    aria-labelledby="servicio3" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title" id="servicio3">Hemodiálisis de alta eficiencia ambulatoria y
                                    extramural
                                </h4>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <p style="text-align: justify;">La diálisis como procedimiento busca eliminar toxinas y
                                    líquido que se acumula cuando los riñones ya no pueden hacer su trabajo. Durante el
                                    tratamiento, la sangre pasa a través de un sistema de líneas hasta un “riñón artificial”
                                    o filtro que se encarga de la depuración. Este procedimiento se realiza dentro de
                                    nuestras instalaciones que cuentan además con sistemas multimedia y ergonómicos pensados
                                    en brindar la mejor experiencia y todo el confort
                                    a nuestros usuarios.</p>
                            </div>
                            <div class="modal-footer">
                                <center><button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                                </center>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4">
                    <div class="icon-box">
                        <div class="icon"><i class="icofont-doctor"></i></div>
                        <h4><a href="#" data-toggle="modal" data-target="#servicio4">Diálisis peritoneal ambulatoria
                                continua y
                                automatizada</a></h4>
                        <p>
                            <!--mensajes de texto-->
                        </p>
                    </div>
                </div>
                <!-- Modal 4-->
                <div class="modal fade" id="servicio4" data-backdrop="static" data-keyboard="false" tabindex="-1"
                    aria-labelledby="servicio4" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title" id="servicio4">Diálisis peritoneal ambulatoria continua y
                                    automatizada
                                </h4>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <p style="text-align: justify;">La diálisis como procedimiento busca eliminar toxinas y
                                    líquido que se acumula cuando los riñones ya no pueden hacer su trabajo. Para la
                                    diálisis peritoneal, utilizamos la cavidad abdominal del paciente como fuente del
                                    intercambio de sustancias y toxinas. Como procedimiento, facilita el acceso al
                                    tratamiento a nuestros pacientes con dificultades para acudir de manera regular a la
                                    unidad renal, pues suministramos todos los elementos
                                    necesarios para que el tratamiento se realice desde su casa y solo acude a nuestra
                                    institución a las consultas de control.</p>
                            </div>
                            <div class="modal-footer">
                                <center><button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                                </center>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4">
                    <div class="icon-box">
                        <div class="icon"><i class="icofont-doctor"></i></div>
                        <h4><a href="#" data-toggle="modal" data-target="#servicio5">Terapias de reemplazo renal
                                continuas</a></h4>
                        <p></p>
                    </div>
                </div>
                <!-- Modal 5-->
                <div class="modal fade" id="servicio5" data-backdrop="static" data-keyboard="false" tabindex="-1"
                    aria-labelledby="servicio5" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title" id="servicio5">Terapias de reemplazo renal continuas
                                </h4>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <p style="text-align: justify;">Las terapias de reemplazo renal continuas buscan la
                                    eliminación de toxinas y líquido que se acumula cuando los riñones no están en la
                                    capacidad de lograrlo de manera adecuada. A diferencia de la diálisis convencional, este
                                    tratamiento se realiza durante las 24 horas del día de manera continua de acuerdo con
                                    las necesidades del paciente. Esto lo condiciona como una mejor alternativa para
                                    pacientes críticamente enfermos.
                                </p>
                                <div class="modal-footer">
                                    <center><button type="button" class="btn btn-secondary"
                                            data-dismiss="modal">Cerrar</button></center>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4">
                    <div class="icon-box">
                        <div class="icon"><i class="icofont-doctor"></i></div>
                        <h4><a href="#" data-toggle="modal" data-target="#servicio6">Gestión integral de accesos para
                                diálisis</a>
                        </h4>
                        <p></p>
                    </div>
                </div>
                <!-- Modal 6-->
                <div class="modal fade" id="servicio6" data-backdrop="static" data-keyboard="false" tabindex="-1"
                    aria-labelledby="servicio6" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title" id="servicio6">Gestión integral de accesos para diálisis
                                </h4>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <p>Para cualquier modalidad de diálisis se requiere del acceso bien sea al torrente
                                    sanguíneo del paciente o a la cavidad abdominal. Es por esto que en NEFROUROS contamos
                                    con los mejores especialistas en la creación, cierre
                                    y reparación de accesos para diálisis y de esta forma consolidarnos como una institución
                                    que aborda la integralidad del paciente con enfermedad renal avanzada.</p>
                                <div class="modal-footer">
                                    <center><button type="button" class="btn btn-secondary"
                                            data-dismiss="modal">Cerrar</button></center>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4">
                    <div class="icon-box">
                        <div class="icon"><i class="icofont-doctor"></i></div>
                        <h4><a href="#" data-toggle="modal" data-target="#servicio7">Hemoperfusión</a></h4>
                        <p></p>
                    </div>
                </div>
                <!-- Modal 6-->
                <div class="modal fade" id="servicio7" data-backdrop="static" data-keyboard="false" tabindex="-1"
                    aria-labelledby="servicio7" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title" id="servicio7"> Hemoperfusión
                                </h4>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <p style="text-align: justify;">La hemoperfusión como tratamiento pretende eliminar
                                    sustancias que se encuentran en la sangre y que se comportan como un agente tóxico para
                                    el organismo. Utiliza de un circuito extracorpóreo conectado a un equipo que se
                                    encarga de extraer parte de la sangre del paciente y a través de un filtro o cartucho
                                    cargado con una sustancia absorbente que se encarga de la extracción del agente
                                    contaminante. Es utilizado para el manejo de intoxicaciones
                                    o sobredosificación de sustancias.</p>
                                <div class="modal-footer">
                                    <center><button type="button" class="btn btn-secondary"
                                            data-dismiss="modal">Cerrar</button></center>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4">
                    <div class="icon-box">
                        <div class="icon"><i class="icofont-doctor"></i></div>
                        <h4><a href="#" data-toggle="modal" data-target="#servicio8"> Plasmaféresis </a></h4>
                        <p></p>
                    </div>
                </div>
                <!-- Modal 7-->
                <div class="modal fade" id="servicio8" data-backdrop="static" data-keyboard="false" tabindex="-1"
                    aria-labelledby="servicio5" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title" id="servicio8">Plasmaféresis
                                </h4>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <p>A través de este procedimiento se busca la extracción del plasma y los diferentes
                                    componentes del sistema inmunológico que allí se encuentran y que se encargan de la
                                    recaída en los síntomas de las enfermedades con un componente
                                    de afectación inmunológica. Este plasma extraído a través de un sistema de filtros que
                                    se encuentran conectados al paciente y sustituido de manera inmediata por plasma de
                                    pacientes sanos o de sustancias que cumplen
                                    la misma función.</p>
                                <div class="modal-footer">
                                    <center><button type="button" class="btn btn-secondary"
                                            data-dismiss="modal">Cerrar</button></center>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

    </section>
    <script>
        document.getElementById("btnabrir1").addEventListener("click", function() {
            document.getElementsByClassName("fondo_uno")[0].style.display = "block"
            return false
        })
        document.getElementsByClassName("modal_cerrar1")[0].addEventListener("click", function() {
            document.getElementsByClassName("fondo_uno")[0].style.display = "none"
        })

        document.getElementById("btnabrir2").addEventListener("click", function() {
            document.getElementsByClassName("fondo_dos")[0].style.display = "block"
            return false
        })
        document.getElementsByClassName("modal_cerrar2")[0].addEventListener("click", function() {
            document.getElementsByClassName("fondo_dos")[0].style.display = "none"
        })

        document.getElementById("btnabrir3").addEventListener("click", function() {
            document.getElementsByClassName("fondo_tres")[0].style.display = "block"
            return false
        })
        document.getElementsByClassName("modal_cerrar3")[0].addEventListener("click", function() {
            document.getElementsByClassName("fondo_tres")[0].style.display = "none"
        })

        document.getElementById("btnabrir4").addEventListener("click", function() {
            document.getElementsByClassName("fondo_cuatro")[0].style.display = "block"
            return false
        })
        document.getElementsByClassName("modal_cerrar4")[0].addEventListener("click", function() {
            document.getElementsByClassName("fondo_cuatro")[0].style.display = "none"
        })

        document.getElementById("btnabrir5").addEventListener("click", function() {
            document.getElementsByClassName("fondo_cinco")[0].style.display = "block"
            return false
        })
        document.getElementsByClassName("modal_cerrar5")[0].addEventListener("click", function() {
            document.getElementsByClassName("fondo_cinco")[0].style.display = "none"
        })

        document.getElementById("btnabrir6").addEventListener("click", function() {
            document.getElementsByClassName("fondo_seis")[0].style.display = "block"
            return false
        })
        document.getElementsByClassName("modal_cerrar6")[0].addEventListener("click", function() {
            document.getElementsByClassName("fondo_seis")[0].style.display = "none"
        })

        document.getElementById("btnabrir7").addEventListener("click", function() {
            document.getElementsByClassName("fondo_siete")[0].style.display = "block"
            return false
        })
        document.getElementsByClassName("modal_cerrar7")[0].addEventListener("click", function() {
            document.getElementsByClassName("fondo_siete")[0].style.display = "none"
        })

        document.getElementById("btnabrir8").addEventListener("click", function() {
            document.getElementsByClassName("fondo_ocho")[0].style.display = "block"
            return false
        })
        document.getElementsByClassName("modal_cerrar8")[0].addEventListener("click", function() {
            document.getElementsByClassName("fondo_ocho")[0].style.display = "none"
        })

    </script>
@endsection
