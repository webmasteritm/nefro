@extends('layauts.plantilla')
@section('content')
    <section id="hero">
        <div id="heroCarousel" class="carousel slide carousel-fade" data-ride="carousel">
            <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>
            <div class="carousel-inner" role="listbox">
                <!-- Slide 1 -->
                <div class="carousel-item active" style="background-image: url(assets/img/slide/slider411.jpg)">
                </div>
                <!-- Slide 2 -->
                <div class="carousel-item" style="background-image: url(assets/img/slide/slider3.jpg)">
                </div>
                <!-- Slide 3 -->
                <div class="carousel-item" style="background-image: url(assets/img/slide/slider6.jpg)">
                </div>
            </div>
            <a class="carousel-control-prev" href="#heroCarousel" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon icofont-simple-left" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#heroCarousel" role="button" data-slide="next">
                <span class="carousel-control-next-icon icofont-simple-right" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </section>
    <!-- End Hero -->
    <br></br>
    <br> </br>
    <!--close slider-->
    <section>
        <div class="service_area">
            <div class="container p-0">
                <div class="row no-gutters">
                    <div class="col-xl-4 col-md-4">
                        <div class="single_service">
                            <div class="icon">
                                <i class="flaticon-electrocardiogram"></i>
                            </div>
                            <h4>Contáctenos</h4>
                            <p>Déjenos un mensaje, con gusto será atendido. </p>
                            <a class="boxed-btn3-white" href="{{ route('Contactenos.home') }}">Enviar un mensaje</a>

                        </div>
                    </div>
                    <div class="col-xl-4 col-md-4">
                        <div class="single_service">
                            <div class="icon">
                                <i class="flaticon-emergency-call"></i>
                            </div>
                            <h4>Citas en línea</h4>
                            <p>Solicite su cita!, con gusto será programada vía correo electrónico.</p>
                            <a href="{{ route('citas.home') }}" class="boxed-btn3-white">Solicitar cita</a>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-4">
                        <div class="single_service">
                            <div class="icon">
                                <i class="flaticon-first-aid-kit"></i>
                            </div>
                            <h4>Evaluación y Sugerencias</h4>
                            <p>Su opinión es muy impórtate para nosotros.</p>
                            <a href="{{ route('sugerir.home') }}" class="boxed-btn3-white">Evaluar o Sugerir</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section>
        <div class="container">
            <div class="section-title">
                <h2><span style="color: #737373;">BIENVENIDOS A </span> <span style="color: #f57d00;">NEFROUROS</span>
                    </span>
                </h2>
                <h4><span style="color: #737373;"> Servimos con el </span> <span style="color: #f57d00;">alma</span> </span>
                </h4>
                <p class="text-align:justify">Nuestro Slogan “Servimos con el Alma”, hace referencia a no perder la
                    oportunidad de marcar una huella positiva en cada una de las personas con la que tenemos contacto como
                    prestadores de servicios de salud, a ser capaces de ponernos en
                    el lugar del otro para entender sus necesidades y asumirlas como si fueran propias, a servir
                    honestamente entregando el corazón por una causa que siendo de otra persona la asumimos como nuestra.
                </p>
            </div>
        </div>
    </section>
    <!-- ======= About Section ======= -->
    <section id="about" class="about">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-5 col-lg-6 video-box d-flex justify-content-center align-items-stretch">
                    <a href="https://player.vimeo.com/video/350985596" class="venobox play-btn mb-4" data-vbtype="video"
                        data-autoplay="true"></a>
                </div>

                <div
                    class="col-xl-7 col-lg-6 icon-boxes d-flex flex-column align-items-stretch justify-content-center py-5 px-lg-5">
                    <div class="container">
                        <div class="section-title">
                            <h2><span style="color: #f57d00"> NEFROUROS</span> <span style="color: #737373;">UNIDAD
                                    RENAL</span> </span>
                            </h2>
                        </div>
                    </div>
                    <div class="icon-box">
                        <div class="icon"><i class="bx bx-fingerprint"></i></div>
                        <h4 class="title"><a href=""><span style="color: #737373;">Gracias por visitar</span> <span
                                    style="color: #f57d00;">NEFROUROS</span></a></h4>
                        <p class="description" style="text-align: justify">Si eres paciente renal y buscas consuelo y
                            esperanza para afrontar tu enfermedad, acá encontraras un lugar diseñado pensando en ti. Somos
                            una empresa especializada en servicios de Nefroprevencion, Hemodiálisis y Diálisis Peritoneal
                            con sedes en Neiva, Ibagué, Pitalito, Tunja, Duitama Montería, Yopal, Barrancabermeja, Medellín,
                            Rionegro, Envigado y Garzón.</p>
                    </div>

                    <div class="icon-box">
                        <div class="icon"><i class="bx bx-happy"></i></div>
                        <h4 class="title"><a href="">Servimos con el alma </a></h4>
                        <p class="description" style="text-align: justify">Con nuestra misión de prestar atención integral
                            al paciente renal con alta calidad científica de la mano de las más alta calidez humana, hemos
                            consolidado una cultura de servicio reconocida a nivel nacional. Queremos que conozcas
                            un poco de nosotros a través de esta página, tenemos diferentes temas de salud, preguntas
                            frecuentes que alguna vez puedes tener, recomendaciones para tu vida</p>
                    </div>

                    <div class="icon-box">
                        <div class="icon"><i class="bx bx-home"></i></div>
                        <h4 class="title"><a href="{{ route('home.actividadesPacientes') }}">Actividades</a></h4>
                        <p class="description" style="text-align: justify">Aqui encontraráslas actividades y eventos que
                            hacemos con nuestros pacientes. Puedes utilizar nuestro servicio de citas en línea con
                            Nefrología, Psicología, Nutrición o Trabajo Social, todos profesionales con amplios
                            conocimientos
                            en el manejo del paciente renal, su patología y los trámites que se deben hacer ante las
                            distintas EPS y EPSs. Esperamos que seas muy activo en esta, tu página y nos dejes tus
                            sugerencias y comentarios todas las veces que quieras.</p>
                    </div>

                </div>
            </div>
        </div>


        </div>
    </section>
    <section>
        <div class="container">
            <div class="section-title">
                <h2><span style="color: #737373;">NUESTRAS </span> <span style="color: #f57d00;">SEDES</span> </span>
                </h2>
                <p>NEFROUROS Unidad renal cuenta con sedes a nivel nacional permitiéndonos prestar servicios de la mejor
                    calidez humana en cualquier parte del país.</p>
            </div>
        </div>
        <div class="site-section pb-0">
            <div class="container">
                <div class="row mb-5 justify-content-center text-center">
                    <div class="col-lg-4 mb-5 text-center">
                    </div>
                    <div class="row">
                        <div class="col-lg-4 col-md-6 mb-5 mb-lg-5">
                            <div class="feature-1 border person text-center">
                                <img src="assets/img/sedes/UR-neiva/Fachada---NEFROUROS.jpg" alt="Image" class="img-fluid">
                                <div class="feature-1-content">
                                    <h3>NEFROUROS</h3>
                                    <h5 style="color: #737373;">Sede Neiva</h5>
                                    <a href="{{ route('sedes.home',['id'=>'1','sede'=>'Neiva']) }}" class="btn-get-started scrollto">Ver sede </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 mb-5 mb-lg-5">
                            <div class="feature-1 border person text-center">
                                <img src="assets/img/sedes/UR-garzon/IMG_9248.jpg" alt="Image" class="img-fluid">
                                <div class="feature-1-content">
                                    <h3>NEFROUROS</h3>
                                    <h5 style="color: #737373;">Sede Garzón</h5>
                                    <a href="{{ route('sedes.home',['id'=>'10','sede'=>'Garzon']) }}" class="btn-get-started scrollto">Ver sede </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 mb-5 mb-lg-5">
                            <div class="feature-1 border person text-center">
                                <img src="assets/img/sedes/UR-Pitalito/pitalito4.jpg" alt="Image" class="img-fluid">
                                <div class="feature-1-content">
                                    <h3>NEFROUROS </h3>
                                    <h5 style="color: #737373;">Sede Pitalito</h5>

                                    <a href="{{ route('sedes.home',['id'=>'2','sede'=>'Pitalito']) }}" class="btn-get-started scrollto">Ver sede </a>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-6 mb-5 mb-lg-5">
                            <div class="feature-1 border person text-center">
                                <img src="assets/img/sedes/UR-ibague/RDSC01131.jpg" alt="Image" class="img-fluid">
                                <div class="feature-1-content">
                                    <h3>NEFROUROS </h3>
                                    <h5 style="color: #737373;">Sede Ibagué</h5>
                                    <a href="{{ route('sedes.home',['id'=>'3','sede'=>'Ibague']) }}" class="btn-get-started scrollto">Ver sede </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 mb-5 mb-lg-5">
                            <div class="feature-1 border person text-center">
                                <img src="assets/img/sedes/UR-envigado/DSC_0029.jpg" alt="Image" class="img-fluid">
                                <div class="feature-1-content">
                                    <h3>NEFROUROS </h3>
                                    <h5 style="color: #737373;">Sede Envigado</h5>
                                    <a href="{{ route('sedes.home',['id'=>'9','sede'=>'Envigado']) }}" class="btn-get-started scrollto">Ver sede </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 mb-5 mb-lg-5">
                            <div class="feature-1 border person text-center">
                                <img src="assets/img/sedes/Nefroprevencion/Nefroprev.jpg" alt="Image" class="img-fluid">
                                <div class="feature-1-content">
                                    <h3>NEFROUROS </h3>
                                    <h5 style="color: #737373;">Sede Medellín-Nefroprevención</h5>
                                    <a href="{{ route('sedes.home',['id'=>'11','sede'=>'Medellin']) }}" class="btn-get-started scrollto">Ver sede </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 mb-5 mb-lg-5">
                            <div class="feature-1 border person text-center">
                                <img src="assets/img/sedes/UR-monteria/monteria1as.jpg" alt="Image" class="img-fluid">
                                <div class="feature-1-content">
                                    <h3>NEFROUROS </h3>
                                    <h5 style="color: #737373;">Sede Monteria</h5>
                                    <a href="{{ route('sedes.home',['id'=>'6','sede'=>'Monteria']) }}" class="btn-get-started scrollto">Ver sede </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 mb-5 mb-lg-5">
                            <div class="feature-1 border person text-center">
                                <img src="assets/img/sedes/UR-Pitalito/pitalito1.jpg" alt="Image" class="img-fluid">
                                <div class="feature-1-content">
                                    <h3>NEFROUROS </h3>
                                    <h5 style="color: #737373;">Sede Barranquilla</h5>
                                    <a href="{{ route('sedes.home',['id'=>'12','sede'=>'Barranquilla ']) }}" class="btn-get-started scrollto">Ver sede </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 mb-5 mb-lg-5">
                            <div class="feature-1 border person text-center">
                                <img src="assets/img/sedes/UR-yopal/DSC_3926.jpg" alt="Image" class="img-fluid">
                                <div class="feature-1-content">
                                    <h3>NEFROUROS </h3>
                                    <h5 style="color: #737373;">Sede Yopal</h5>
                                    <a href="{{ route('sedes.home',['id'=>'7','sede'=>'Yopal']) }}" class="btn-get-started scrollto">Ver sede </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 mb-5 mb-lg-5">
                            <div class="feature-1 border person text-center">
                                <img src="assets/img/sedes/UR-tunja/FACHADA.jpg" alt="Image" class="img-fluid">
                                <div class="feature-1-content">
                                    <h3>NEFROUROS </h3>
                                    <h5 style="color: #737373;">Sede Tunja</h5>
                                    <a href="{{ route('sedes.home',['id'=>'5','sede'=>'Tunja']) }}" class="btn-get-started scrollto">Ver sede </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 mb-5 mb-lg-5">
                            <div class="feature-1 border person text-center">
                                <img src="assets/img/sedes/UR-duitama/ENTRADA.jpg" alt="Image" class="img-fluid">
                                <div class="feature-1-content">
                                    <h3>NEFROUROS </h3>
                                    <h5 style="color: #737373;">Sede Duitama</h5>
                                    <a href="{{ route('sedes.home',['id'=>'4','sede'=>'Duitama']) }}" class="btn-get-started scrollto">Ver sede </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 mb-5 mb-lg-5">
                            <div class="feature-1 border person text-center">
                                <img src="assets/img/sedes/UR-barrancabermeja/_DEA9562.jpg" alt="Image" class="img-fluid">
                                <div class="feature-1-content">
                                    <h3>NEFROUROS </h3>
                                    <h5 style="color: #737373;">Sede Barrancabermeja</h5>
                                    <a href="{{ route('sedes.home',['id'=>'8','sede'=>'Barrancabermeja']) }}" class="btn-get-started scrollto">Ver sede </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 mb-5 mb-lg-5">
                            <div class="feature-1 border person text-center">
                                <img src="assets/img/sedes/UR-rionegro/IMG_8669.jpg" alt="Image" class="img-fluid">
                                <div class="feature-1-content">
                                    <h3>NEFROUROS </h3>
                                    <h5 style="color: #737373;">Sede Rionegro</h5>
                                    <a href="{{ route('sedes.home',['id'=>'13','sede'=>'Rionegro']) }}" class="btn-get-started scrollto">Ver sede </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
        <!-- End Contact Section -->
        <!-- <section id="test-form" class="test-form">
    <div class="popup_box"> 
    </section> End Contact Section   permite mostrar un texto dentro de la misma pagina -->
        <!-- offers_area_start -->

        <!-- offers_area_end -->
        <!--===============================================END SECTION OF BLOG NOTICE=================================-->
    </section>
@endsection
