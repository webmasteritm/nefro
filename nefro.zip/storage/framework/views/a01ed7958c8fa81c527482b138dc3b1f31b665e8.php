
<?php $__env->startSection('title', 'Nefrouros|Editar-Noticia'); ?>
<?php $__env->startSection('content'); ?>
<style>
    .dirty-dash {
    }
    
    .prueba {
        background-color: #f57d00;
    }
    .gal {
        width: 150px;
        height: 150px;
        float: left;
        margin: 1%;
    }
    .btn-outline-danger {
        background-color: transparent;
        border-radius: 80%;
        border-color: transparent;
        margin-left: 35%;
    }
    .bi-trash {
        color: black;
        width: -150px;
        
    }
    </style>
    <link href="assets/img/favicon.png" rel="icon">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="/assets/css/style.css">
    <section class="container-fluid" style="background-color: white; height:900px;">
        <header>
            <div class="container-fluid" style="background-color: white">
                <img src="https://nefrouros.net/assets/img/05.png">

            </div>
        </header>
        <br>

        <hr class="prueba">

        <form method="post" action="<?php echo e(route('actualizar-noticia', ['id' => $noticias->id_noticia])); ?>"
            enctype="multipart/form-data" class="php-email-form alerta">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="nombre">Nombre</label>
                    <input type="text" class="form-control" value="<?php echo e($noticias->nombre_noticia); ?>" name='nombre'
                        id="nombre">
                </div>
                <div class="form-group col-md-6">
                    <label for="tetx">Fecha </label>
                    <input type="text" class="form-control" name="fecha" id="fecha"
                        value="<?php echo e($noticias->fecha_noticia); ?>">
                </div>
                <div class="form-group col-md-6">
                    <label for="detalles">detalles</label>
                    <textarea class="form-control" id="detalles" name="detalles"
                        placeholder="Describa la noticia"><?php echo e($noticias->detalles_noticia); ?></textarea>
                </div>


                <div class="form-group col-md-6">
                    <label for="categotria">Categoria:</label>
                    <select id="categotria" class="form-control" name='categoria' id="categotria">
                        <option value="<?php echo e($noticias->id_categoria); ?>"><?php echo e($noticias->id_categoria); ?></option>
                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->categoria); ?></option>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>
                </div>
                <div class="form-group col-md-6">
                    <label for="imagen_princial">Imagen principal</label>
                    <input type="file" name="imagen_princial[]" id="imagen_princial[]" accept="image/*">
                </div>
                <div class="form-group col-md-6">
                    <label for="imagenes_noticias">Imagenes Noticias</label>
                    <input type="file" multiple name="imagenes_noticias[]" id="imagenes_noticias[]" accept="image/*">
                </div>
                <div class=" col-md-6">
                    <button type="submit" class="btn btn-primary" name='btn_send' style="margin-left: 80%">Enviar </button>
                </div>
            </div>
        </form>
        <div class="col-sm-12">
            <h5>Imagenes de la noticia</h5>
            <?php $__currentLoopData = $imagen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


            <div class="gal">

                <div class="dirty-dash">
                    <div>
                        <div class="card">
                            
                                <form action="<?php echo e(route('delete.imagenoticia', ['id' => $k->id])); ?>" method="POST">
                                    <img src="<?php echo e($k->url); ?>" alt="" class="img-fluid" style="width:250px">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>
                                    <button type="submit" class="btn btn-outline-danger" style="border-radius:80%"><i
                                        class="bi bi-trash"></i></button>

                                </form>

                            </div>

                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nefro\resources\views/galeria/editar-noticia.blade.php ENDPATH**/ ?>