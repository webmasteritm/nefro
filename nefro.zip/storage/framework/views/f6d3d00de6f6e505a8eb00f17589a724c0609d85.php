
<?php $__env->startSection('content'); ?>
    <section id="hero">
        <div id="heroCarousel" class="carousel slide carousel-fade" data-ride="carousel">

            <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>

            <div class="carousel-inner" role="listbox">
                <!-- Slide 1 -->
                <div class="carousel-item active" style="background-image: url(../assets/img/sedes/UR-tunja/FACHADA.jpg)">
                    <div class="container">
                        <h2><span style="color: #F57D00;">NEFROUROS</span> <span style="color: #737373;">SEDE TUNJA</span>
                        </h2>
                        <a href="<?php echo e(route('citas.home')); ?>" class="btn-get-started scrollto">Citas en linea</a>
                    </div>
                </div>
                <!-- Slide 2 -->
                <div class="carousel-item" style="background-image: url(../assets/img/sedes/UR-tunja/SALA-PACIENTE.jpg)">
                </div>
                <!-- Slide 3 -->
                <div class="carousel-item" style="background-image: url(../assets/img/sedes/UR-tunja/SALA-ESPERA.jpg)">
                </div>
            </div>
            <div class="carousel-item" style="background-image: url(../assets/img/sedes/UR-tunja/SALA-ESPERA.jpg)">
            </div>
        </div>

        <a class="carousel-control-prev" href="#heroCarousel" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon icofont-simple-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>

        <a class="carousel-control-next" href="#heroCarousel" role="button" data-slide="next">
            <span class="carousel-control-next-icon icofont-simple-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>

        </div>
    </section>
    <!-- End Hero -->

    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <section id="contact" class="contact">

        <div class="container">
            <div class="section-title">
                <h2><span style="color: #F57D00;">NEFROUROS</span> <span style="color: #737373;">SEDE TUNJA</span></h2>
                <p>Puede contactar nuestra unidad renal en la ciudad de tunja ,diligencie el formulario y verifique que sus
                    datos esten correctos. </p>
            </div>
        </div>
        <div>
        </div>


        <div class="container">
            <div class="row mt-5">
                <?php if (isset($msg)) {
                echo $msg;
                } ?>

                <div class="col-lg-4">
                    <div class="info">
                        <div class="address">
                            <i class="icofont-google-map"></i>
                            <h4>Ubicación:</h4>
                            <p>Carrera 11 No 27-27 Hospital San Rafael, Sótano 1 - Tunja,Boyacá</p>
                        </div>

                        <div class="email">
                            <i class="icofont-envelope"></i>
                            <h4>Email:</h4>
                            <p>gerenciatunja@nefrouros.net</p>
                        </div>

                        <div class="phone">
                            <i class="icofont-phone"></i>
                            <h4>Teléfonos:</h4>
                            <p>(8)740 0246 – (03)316 523 3061</p>
                        </div>

                    </div>

                </div>

                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.formulario-contacto','data' => []]); ?>
<?php $component->withName('formulario-contacto'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

            </div>
    
        </div>
    </section>  
    
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('js'); ?> 
    
    
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.formulario-script','data' => []]); ?>
<?php $component->withName('formulario-script'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layauts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nefro\resources\views/sedes/sede-5-Tunja.blade.php ENDPATH**/ ?>