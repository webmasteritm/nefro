
<?php $__env->startSection('content'); ?>
    <br> <br>
    <br> <br>
    <section class="blog_area section-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mb-5 mb-lg-0">
                    <div class="blog_left_sidebar">
                        <?php $__currentLoopData = $detalles_blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <article class="blog_item">
                                <div class="blog_item_img">
                                    <img class="card-img rounded-0" src="<?php echo e($item->imagen_principal); ?>" width="500px"
                                        height="400px" alt="">
                                    <a href="#" class="blog_item_date">
                                        <P><?php echo e($item->fecha_noticia); ?></P>
                                    </a>
                                </div>
                                <div class="blog_details">
                                    <a class="d-inline-block" href="">
                                        <h2><?php echo e($item->nombre_noticia); ?></h2>
                                    </a>
                                    <p class="text-justify"> <?php echo e($item->detalles_noticia); ?></p>
                                    <section id="gallery" class="gallery">
                                        <div class="container">
                                            <div class="container-fluid">
                                                <div class="row no-gutters">
                                                    <?php $__currentLoopData = $imagenes_blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="col-lg-3 col-md-4">
                                                            <div class="gallery-item">
                                                                <a href="<?php echo e($item->url); ?>" class="venobox"
                                                                    data-gall="gallery-item">
                                                                    <img src="<?php echo e($item->url); ?>" alt="" class="img-fluid">
                                                                    <div class="experts_name text-center">
                                                                    </div>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </div>

                                            </div>
                                        </div>
                                    </section>
                            </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
                
                <div class="col-lg-4">
                    <div class="blog_right_sidebar">
                        <br><br><br><br><br><br><br>
                        <aside class="single_sidebar_widget post_category_widget">
                            <h4 class="widget_title">Noticias recientes</h4>
                            <ul class="list cat-list">
                                <?php $__currentLoopData = $reciente_blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e(route('blogdetalles.home', ['id' => $item->id_noticia, 'categoria' => $categoria])); ?>"
                                            class="d-flex">
                                            <p><?php echo e($item->nombre_noticia); ?></p>

                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>
                        </aside>
                    </div>
                </div>
            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layauts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nefro\resources\views/Blognoticias/index-detalles.blade.php ENDPATH**/ ?>