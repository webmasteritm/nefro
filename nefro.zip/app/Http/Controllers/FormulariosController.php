<?php

namespace App\Http\Controllers;

use App\Mail\Contactenos;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Mail\CitasEnlinea;
use App\Mail\Sugerencias;
use GrahamCampbell\ResultType\Success;

class FormulariosController extends Controller
{
    public function contactenos()
    {
        return view('formularios.contactenos');
    }
    public function citas()
    {
        return view('formularios.citasEnlinea');
    }
    public function sugerencias()
    {
        return view('formularios.Sugerencias');
    }
    public function enviarContactenos(Request $request)
    {

        $verificacion = $request->input('verificacion');


        if ($verificacion == 1030) {
            $contactenos = new Contactenos($request->all());
            $contactenos->replyTo($request->input('email'));
            $sedes = $request->input('sedes');
            //$sede = $request->input('sede'); 
            //$emails = array($sede,$sedes);    array para multiples destinatarios validar en el imput o la opcion select del value gerencias      
            Mail::to($sedes)->send($contactenos);
            return redirect()->back()
                ->with('success', 'ok');
        } else {

            return redirect()->back()
                ->with('success', 'error');
        }
    }
    public function enviarCitas(Request $request)
    {
        $verificacion = $request->input('verificacion');
        if ($verificacion == 1030) {


            $citas = new CitasEnlinea($request->all());
            $citas->replyTo($request->input('email'));

            $sedes = $request->input('sedes');
            Mail::to($sedes)->send($citas);
            return redirect()->route('citas.home')->with('success', 'ok');
        } else {
            return redirect()->route('citas.home')->with('success', 'error');
        }
    }
    public function enviarSugerencias(Request $request)
    {
        $verificacion = $request->input('verificacion');
        if ($verificacion == 1030) {


            $citas = new Sugerencias($request->all());

            $sedes = $request->input('sedes');
            Mail::to($sedes)->send($citas);
            return redirect()->route('sugerir.home')->with('success', 'ok');
        } else {
            return redirect()->route('sugerir.home')->with('success', 'error');
        }
    }
}
