<?php

use App\Http\Controllers\ActividadController;
use App\Http\Controllers\ActividesController;
use App\Http\Controllers\BlogController;
use App\Http\Controllers\CalendarioActividadesController;
use App\Http\Controllers\copasstController;
use App\Http\Controllers\EmailController;
use App\Http\Controllers\FormulariosController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\SedeController;
use App\Models\Actividad;
use App\Models\CalendarioActividades;
use App\Models\Sede;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [HomeController::class, 'Index'])->name('home.inicio');
Route::get('Servicios', [HomeController::class, 'servicios'])->name('home.servicios');
Route::get('Plataforma-Estrategica', [HomeController::class, 'plataformaEstrategica'])->name('home.plataformaEstrategica');
Route::get('Codigos-De-Etica', [HomeController::class, 'codigosdeEtica'])->name('home.codigosdeEtica');
Route::get('Estados-Financieros', [HomeController::class, 'estadosFinancieros'])->name('home.estadosFinancieros');
Route::get('Sarlaft', [HomeController::class, 'Sarlaft'])->name('home.Sarlaft');
Route::get('Calendario-De-Actividades', [HomeController::class, 'CalendaiodeActividades'])->name('home.Calendario');
Route::get('Derechos-Y-Deberes', [HomeController::class, 'DerechosyDeberes'])->name('home.DerechosyDeberes');
Route::get('Valore-Agregados', [HomeController::class, 'ValoreAgregados'])->name('home.ValoreAgregados');
Route::get('Actividades-Pacientes', [HomeController::class, 'ActividadesPacientes'])->name('home.actividadesPacientes');
Route::get('Preguntas-frecuentes', [HomeController::class, 'prefuntasFrecuentes'])->name('prefuntasFrecuentes.home');

//<===========================Fin Rutas principales
//>=========================Rutas Copasst
Route::get('Informe-Nefrouros-Fundacion', [copasstController::class, 'nefrourosFundacion'])->name('copasst.nefrourosFundacion');
Route::get('Informe-Nefroservicios-Sas', [copasstController::class, 'nefroServicios'])->name('copasst.nefroServicios');
Route::get('Informe-SesSalud', [copasstController::class, 'sesSalud'])->name('copasst.sesSalud');
Route::get('Informe-Nefrouros-Mom-Garzon', [copasstController::class, 'Garzon'])->name('copasst.Garzon');
Route::get('Informe-Nefrouros-Mom-Envigado', [copasstController::class, 'Envigado'])->name('copasst.Envigado');
Route::get('Informe-Nefrouros-Mom-Rionegro', [copasstController::class, 'Rionegro'])->name('copasst.Rionegro');
Route::get('Informe-Nefrouros-Mom-Pitalito', [copasstController::class, 'Pitalito'])->name('copasst.Pitalito');

//>=============================== Rutas Emails
Route::get('Contactenos', [FormulariosController::class, 'contactenos'])->name('Contactenos.home');
Route::post('enviarcontactenos', [FormulariosController::class, 'enviarContactenos'])->name('enviar.contactenos');
Route::get('Citas-En-Linea', [FormulariosController::class, 'citas'])->name('citas.home');
Route::post('enviarCita', [FormulariosController::class, 'enviarCitas'])->name('enviar.citas');
Route::get('Evaluar-O-Sugerir', [FormulariosController::class, 'sugerencias'])->name('sugerir.home');
Route::post('EnviarSugerencias', [FormulariosController::class, 'enviarSugerencias'])->name('enviar.sugerencias');

//>================================== Actividades 
Route::get('actividades-{sede}-{id}', [HomeController::class, 'actividadGaleria'])->name('actividades.galeria'); // actividadGaleria
Route::get('pacientes-actividades-{sede}-{id}', [HomeController::class, 'todasLasactividades'])->name('actividades.pacientes');
Route::post('img_upload', [ActividadController::class, 'store'])->name('imgActividadUpload');
Route::get('Subir-actividad', [ActividadController::class, 'index'])->name('upload.files');


//>================================Route Galeria de actividades

//======================> Sedes 

Route::get('Sede-{id}-{sede}', [SedeController::class, 'index'])->name('sedes.home');

//===============>>>>>>>>>>>>>>> Blog de noticicias 

Route::get('Blog-de-Noticias', [BlogController::class, 'index'])->name('blog.home');
Route::get('Subir-noticia', [BlogController::class, 'create'])->name('subir.blog');
Route::post('Noticia-upgrade', [BlogController::class, 'store'])->name('update.blog');

Route::get('Blog-{id}-{categoria}', [BlogController::class, 'blogdetalles'])->name('blogdetalles.home');
Route::get('Subir-calendario', [CalendarioActividadesController::class, 'index'])->name('calendario.home');
Route::post('upload-calendario', [CalendarioActividadesController::class, 'store'])->name('update.calendario');
