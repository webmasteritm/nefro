
<?php $__env->startSection('content'); ?>
    <section id="departments" class="departments">
        <div class="container">
            <div class="section-title">
                <br>
                <h2><span style="color: #737373;">CALENDARIO DE </span> <span style="color: #f57d00;">ACTIVIDADES</span>
                    </span>
                </h2>
                <i class="icofont-ui-calendar"></i>
                <?php $__currentLoopData = $mes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p><?php echo e($meses->id_mesdate); ?></p>
                    <p><?php echo e($meses->meses); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="row">

                <div class="col-lg-3">

                    <ul class="nav nav-tabs flex-column">
                        <li class="nav-item">
                            <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actividad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="nav-link" data-toggle="tab" href="#tab-<?php echo e($actividad->id); ?>"><i
                                        class="icofont-ui-next"></i>&nbsp;<?php echo e($actividad->fecha); ?>:
                                    <?php echo e($actividad->actividad); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </li>
                    </ul>
                </div>
                <div class="col-lg-9 mt-4 mt-lg-0">
                    <div class="tab-content">
                        <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actividad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="tab-pane active" id="tab-<?php echo e($actividad->id); ?>">
                                <div class="row">
                                    <div class="col-lg-8 details order-2 order-lg-1">
                                            <h3>Actividad : <?php echo e($actividad->actividad); ?></h3>
                                        </h3>
                                        <p class="font-poppins ">


                                        <p><a class="fin" href=""><i class="icofont-check"></i>&nbsp;<?php echo e($actividad->detalles); ?></a></p>
                                        <h5 style="color: #737373;"><i class="icofont-wall-clock"> <?php echo e($actividad->fecha); ?> </i></h5>
                                        </p>
                                    </div>
                                    <div class="col-lg-4 text-center order-1 order-lg-2">
                                        <img src="" class="img-fluid">
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
          

        </div>
        
       
        <br><br><br><br><br><br>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layauts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nefro\resources\views/CalendariodeActividades.blade.php ENDPATH**/ ?>