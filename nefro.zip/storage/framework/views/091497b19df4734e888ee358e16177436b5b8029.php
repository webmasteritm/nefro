
<?php $__env->startSection('content'); ?>
    <br>
    <br>
    <section id="contact" class="contact">
        <div class="container">
            <div class="section-title">
                <div class="section-title">
                    <h2><span style="color: #F57D00;">NEFROUROS</span> <span style="color: #737373;">CONTACTENOS</span></h2>
                    <p>Comunícate con nosotros </p>
                </div>
            </div>
        </div>
        <div class="contact-form">
            <div class="mt-5 row">
                <div class="col-lg-4">
                    <div class="info">
                        <div class="address">
                            <i class="icofont-google-map"></i>
                            <h4>Ubicaci&oacute;n</h4>
                            <p>En la seccion sedes del menu principal encontrara informaci&oacute;n detallada de la sede de
                                su interes.</p>
                        </div>
                        <div class="email">
                            <i class="icofont-envelope"></i>
                            <h4>envianos un mensaje:</h4>
                            <p>Nefrouros ofrece a todos nuestros pacientes la posibilidad que contactar,enviar sugerencias o
                                pedir citas por medio de nefrouros.net.</p>
                        </div>

                        <div class="phone">
                            <i class="icofont-phone"></i>
                            <h4>Llamanos:</h4>
                            <p>En la seccion sedes del menu principal encontrara informaci&oacute;n detallada de la sede de
                                su interes.</p>
                        </div>

                    </div>

                </div>

                
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.formulario-contacto','data' => []]); ?>
<?php $component->withName('formulario-contacto'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

    
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.formulario-script','data' => []]); ?>
<?php $component->withName('formulario-script'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layauts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nefro\resources\views/formularios/contactenos.blade.php ENDPATH**/ ?>