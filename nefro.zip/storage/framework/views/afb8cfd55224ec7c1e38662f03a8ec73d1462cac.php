
<?php $__env->startSection('title', 'NEFROUROS::Subir-actividad'); ?>
<?php $__env->startSection('content'); ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous">
    </script>
    <form= action="<?php echo e(route('actividades.galeria')); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="col-sm-12">
            <div class="form-group">
                <strong>actividad:</strong>
                <input type="text" name="actividad" class="form-control" placeholder="actividad"
                    value="<?php echo e('$actividad->nombre'); ?>">
            </div>
        </div>
        <div class="col-sm-12">
            <div class="form-group">
                <strong>descripcion:</strong>
                <input type="text" name="descripcion" class="form-control" placeholder="Descripcion de la actividad">
            </div>
        </div>
        <div class="text-center col-sm-12">

            <button type="submit" class="btn btn-primary">Confirmar</button>

        </div>
        </div>
        </form>
        </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\dashboard\resources\views/galeria/editar-actividad.blade.php ENDPATH**/ ?>