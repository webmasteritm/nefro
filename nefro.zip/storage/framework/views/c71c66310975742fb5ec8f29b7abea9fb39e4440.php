
<?php $__env->startSection('title', 'NEFROUROS::Subir-actividad'); ?>
<?php $__env->startSection('content'); ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
    <br>
    <br>
    <div id="contact" class="contact">
        <form action="<?php echo e(route('imgActividadUpload')); ?>" enctype="multipart/form-data" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group">
                        <strong>Imagenes:</strong>
                        <input type="file" multiple name="imagen_actividad[]" id="imagen_actividad[]" accept="image/*">
                    </div>
                </div>
                <div class="col-sm-12">
                    <div class="form-group">
                        <strong>Selecione la imagen principal:</strong>
                        <input type="file" name="imagen_principal[]" id="imagen_principal[]" accept="image/*">
                    </div>
                </div>
                <div class="col-sm-12">
                    <div class="form-group">
                        <strong>sede:</strong>
                        <select class="custom-select" id="sede" name="sede">
                            <option selected>Cancelar</option>
                            <?php $__currentLoopData = $sedes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->sede); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                    </div>
                </div>
                <div class="col-sm-12">
                    <div class="form-group">
                        <strong>actividad:</strong>
                        <input type="text" name="actividad" class="form-control" placeholder="actividad">
                    </div>
                </div>
                <div class="col-sm-12">
                    <div class="form-group">
                        <strong>descripcion:</strong>
                        <input type="text" name="descripcion" class="form-control"
                            placeholder="Descripcion de la actividad">
                    </div>
                </div>
                <div class="text-center col-sm-12">
                    <a href="javascript: history.go(-1)" class="btn btn-success">CANCELAR</a>
                    <button type="submit" class="btn btn-primary">ENVIAR</button>
                    
                </div>
            </div>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\dashboard\resources\views/galeria/subir-actividad.blade.php ENDPATH**/ ?>