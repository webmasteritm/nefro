
<?php $__env->startSection('content'); ?>
    <section id="contact" class="contact">

        <div class="container">

            <div class="section-title">
                <h2><span style="color: #F57D00;">CITAS EN </span> <span style="color: #737373;">LINEA </span></h2>

                <p>Nefrouros ofrece a todos nuestros pacientes la posibilidad que pedir su cita por medio de nefrouros.net
                    Por favor gestione el siguiente formulario para solicitar su cita. </p>
            </div>
        </div>
        <div class="container">
            <div class="mt-5 row">

                <div class="col-lg-4">
                    <div class="info">
                        <div class="address">
                            <i class="icofont-google-map"></i>
                            <h4>Ubicaci&oacute;n</h4>
                            <p>En la seccion sedes del menu principal encontrara informaci&oacute;n detallada de la sede de
                                su interes.</p>
                        </div>

                        <div class="email">
                            <i class="icofont-envelope"></i>
                            <h4>envianos un mensaje:</h4>
                            <p>Nefrouros ofrece a todos nuestros pacientes la posibilidad que contactar,enviar sugerencias o
                                pedir citas por medio de nefrouros.net</p>
                        </div>

                        <div class="phone">
                            <i class="icofont-phone"></i>
                            <h4>Llamanos:</h4>
                            <p>En la seccion sedes del menu principal encontrara informaci&oacute;n detallada de la sede de
                                su interes.</p>
                        </div>

                    </div>

                </div>
                <div class="mt-5 col-lg-8 mt-lg-0">



                    <form method="post" action="<?php echo e(route('enviar.citas')); ?>" class="php-email-form alerta">
                        <?php echo csrf_field(); ?>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="nombre">Nombres</label>
                                <input type="text" class="form-control" placeholder="Ejemplo: Andres Felipe Medina"
                                    name='nombre' id="nombre">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="email">Email</label>
                                <input type="email" class="form-control" placeholder="Ejemplo: Andres12@gmail.com"
                                    name="email" id="email">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="telefono">Tel&eacute;fono</label>
                                <input type="text" class="form-control" placeholder="Ejemplo: 317  667 6549" name="telefono"
                                    id="telefono">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="direccion">Dirección</label>
                                <input type="text" class="form-control" placeholder="Ejemplo:Carrera 15 - calle 9 esquina "
                                    name='direccion' id="direccion">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="entidad">Entidad Prestadora de Salud</label>
                                <input type="text" class="form-control" placeholder="Ejemplo:EPS " name='entidad'
                                    id="entidad">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="Fecha">Fecha probable de Cita</label>
                                <input type="date" class="form-control" id="fecha" name='fecha' placeholder="Fecha">
                            </div>
                            <div>
                                <label for="verificacion">Digite este código:1030</label>
                                <input type="text" class="form-control" placeholder="verficacion" name="verificacion" id="verificacion required>
                    
                                </div>
                                <div class=" form-group col-md-6">
                                <label for="sedes">Sede donde desea la cita (obligatorio):</label>
                                <select class="form-control" name='sedes' id="sedes">
                                    <option selected>Seleccionar</option>
                                    <option value="webmaster@itmsas.net">Neiva</option>
                                    <option value="gerenciapitalito@nefrouros.net">Pitalito</option>
                                    <option value="gerenciaibague@nefrouros.net">Ibague</option>
                                    <option value="gerenciatunja@nefrouros.net">Tunja</option>
                                    <option value="gerenciatunja@nefrouros.net">Duitama</option>
                                    <option value="gerenciamonteria@nefrouros.net">Monter&iacute;a</option>
                                    <option value="gerenciasessalud@nefrouros.net">Yopal</option>
                                    <option value="gerencianefroservicios@nefrouros.net">Barrancabermeja</option>
                                    <option value="gerenciaenvigado@nefrouros.net">Envigado</option>
                                    <option value="gerenciagarzon@nefrouros.net">Garz&oacute;n</option>
                                    <option value="gerencianefroprev.medellin@nefrouros.net">Nefroprevenci&oacute;n</option>
                                    <option value="coordinacionnefroprevencionzonanorte@nefrouros.net">Rionegro</option>
                                    <option value="gerenciabarranquilla@nefrouros.net">Barranquilla</option>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="genero">Genero</label>
                                <select id="genero" class="form-control" name='genero' id="genero">
                                    <option selected>Seleccionar</option>
                                    <option>Maculino </option>
                                    <option>Femenino </option>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="fena">Fecha de Nacimiento</label>
                                <input type="date" class="form-control" id="fechan" name='fena' placeholder="fena">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="mensaje">Mensaje</label>
                                <textarea class="form-control" id="mensaje" name="mensaje"
                                    placeholder="Describa en motivo de su cita"></textarea>
                            </div>
                            <button type="submit" class="btn btn-success" name='btn_send'>Pedir Cita </button>
                    </form>

                </div>

            </div>

        </div>
    </section><!-- End Contact Section -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <?php if($mensaje = Session::get('success')): ?>
        <?php if($mensaje == 'ok'): ?>
            <script>
                Swal.fire(
                    'Enviado!',
                    'Se enviaron los datos de cita Correctamente,Pronto recibira una notificacion a su correo eletronico!',
                    'success'
                )

            </script>
        <?php else: ?>
            <script>
                Swal.fire(
                    'Se produjo un error!',
                    'uups! Vaya al parecer hay un problema al enviar su solicitud',
                    'error'
                )

            </script>
        <?php endif; ?>
    <?php endif; ?>
    <script>
        $('.alerta').submit(function(e) {
            e.preventDefault();
            swal.fire({
                title: "Enviar sus datos?",
                text: "por favor verifique y confirme!",
                type: "warning",
                showCancelButton: !0,
                confirmButtonText: "Si,Acepto!",
                cancelButtonText: "No, cancelar!",
                reverseButtons: !0
            }).then((result) => {
                if (result.value) {
                    this.submit();
                } else if (result.dismiss === Swal.DismissReason.cancel) {
                    Swal.fire(
                        'Cancelado',
                        'Se cancelo el envio vuelve a intentarlo!',
                        'error'
                    )
                }
            })
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layauts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nefrouros.net\resources\views/formularios/citasEnlinea.blade.php ENDPATH**/ ?>