
<?php $__env->startSection('title', 'Nefrouros|Editar-Calendario'); ?>
<?php $__env->startSection('content'); ?>
    <link href="assets/img/favicon.png" rel="icon">
    <link rel="stylesheet" href="/assets/css/style.css">
    <section class="container-fluid" style="background-color: white">
        <header>
            <div class="container-fluid" style="background-color: white">
                <img src="https://nefrouros.net/assets/img/05.png">

            </div>
        </header>
        <br>

        <hr class="prueba">
        <form method="post" action="<?php echo e(route('actualizar-calendario', ['id' => $actividad->id])); ?>"
            class="php-email-form alerta">
            <?php echo method_field('put'); ?>
            <?php echo csrf_field(); ?>




            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="nombre">actividad</label>
                    <input type="text" class="form-control" value="<?php echo e($actividad->actividad); ?>" name='actividad'
                        id="actividad">
                </div>
                <div class="form-group col-md-6">
                    <label for="tetx">Fecha </label>
                    <input type="text" class="form-control" value="<?php echo e($actividad->fecha); ?>" name="fecha" id="fecha">
                </div>
                <div class="form-group col-md-6">
                    
                        <label for="detalles">detalles</label>
                        <textarea class="form-control" id="detalles" name="detalles"
                            placeholder="Describa la noticia"><?php echo e($actividad->detalles); ?></textarea>
                   
                </div>
                

                <div class="form-group col-md-6">
                    <label for="idcalendario">MES:</label>
                    <select id="idcalendario" class="form-control" name='idcalendario' id="idcalendario">
                        <option value="<?php echo e($actividad->id_calendario); ?>"><?php echo e($actividad->id_calendario); ?></option>
                        <?php $__currentLoopData = $meses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($mes->id); ?>"><?php echo e($mes->meses); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>
                </div>

                <div class=" col-md-12">
                    <button type="submit" class="btn btn-primary" name='btn_send' style="margin-left: 50%">Enviar </button>
                </div>
            </div>



        </form>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nefro\resources\views/galeria/editar-calendario.blade.php ENDPATH**/ ?>