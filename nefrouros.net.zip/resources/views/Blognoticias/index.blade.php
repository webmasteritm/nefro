@extends('layauts.plantilla')
@section('content')
    <br>
    <section>
        <div class="site-section pb-0">
            <div class="container">
                <div class="row mb-5 justify-content-center text-center">
                    <div class="col-lg-4 mb-5 text-center">
                    </div>
                    <!--=================================================BLOG DE NOTICIAS pacientes =====================================================-->

                    <div class="container">
                        <div class="row mb-5 justify-content-center text-center">
                            <div class="col-lg-4 mb-5 text-center">
                            </div>
                            <div class="container">
                                <div class="section-title">
                                    <h2><span style="color: #737373;">BLOG DE NOTICIAS COMPAÑERO Y PACIENTE DEL MES </span> <span
                                            style="color: #f57d00;">NEFROUROS</span> </span>
                                    </h2>
                                    <p>Nuestras noticias mas recientes <br> NEFROUROS le actualiza lo que sucede en nuestras
                                        Unidades Renales </p>
                                </div>
                            </div>
                        </div>
                        <div class="row mb-5 justify-content-center text-center">
                            @foreach ($pacientes_blog as $item)
                            <div class="col-lg-4 col-md-6 mb-5 mb-lg-5">
                                <div class="feature-1 border person text-center">
                                    <img src="{{ $item->imagen_principal }}" width="348px" height="180px">
                                    <div class="feature-1-content">
                                        <h5>{{ $item->nombre_noticia }}</h5>
                                        <span class="position mb-3 d-block" style="color: #f57d00;">{{ $item->fecha_noticia }} </span>
                                        @php
                                            $value = Str::limit($item->detalles_noticia, 120);
                                        @endphp
                                        <p style="text-align: justify">{{ $value}}  </p>
                                        <a href="{{ route('blogdetalles.home',['id' =>$item->id_noticia, 'categoria'=>$item->categoria]) }}" class="btn-get-started scrollto">ver mas + </a>
                                    </div>
                                </div>
                            </div>
                          @endforeach                         
                            
                        </div>
                        <nav class="blog-pagination justify-content-center d-flex">
                            <ul class="pagination">
                                <ul class="pagination">
                                    <li class="page-item">
                                        {{ $pacientes_blog->links() }}
                                    </li>
                
                                </ul>
                            </ul>
                        </nav>
                    </div>

                    <!--=================================================BLOG DE NOTICIAS SALUDABLES=====================================================-->
                    <div class="container">
                        <div class="row mb-5 justify-content-center text-center">
                            <div class="col-lg-4 mb-5 text-center">
                            </div>
                            <div class="container">
                                <div class="section-title">
                                    <h2><span style="color: #737373;">BLOG DE NOTICIAS SALUDABLES </span> <span
                                            style="color: #f57d00;">NEFROUROS</span> </span>
                                    </h2>
                                    <p>Nuestras noticias mas recientes <br> NEFROUROS le actualiza lo que sucede en nuestras
                                        Unidades Renales </p>
                                </div>
                            </div>
                        </div>
                        <div class="row mb-5 justify-content-center text-center">
                            @foreach ($saludables_blog as $item)
                            <div class="col-lg-4 col-md-6 mb-5 mb-lg-5">
                                <div class="feature-1 border person text-center">
                                    <img src="{{ $item->imagen_principal }}" width="160px" height="180px">
                                    <div class="feature-1-content">
                                        <h5>{{ $item->nombre_noticia }}</h5>
                                        <span class="position mb-3 d-block" style="color: #f57d00;">{{ $item->fecha_noticia }} </span>
                                        @php
                                            $value = Str::limit($item->detalles_noticia, 120);
                                        @endphp
                                        <p style="text-align: justify">{{ $value}}  </p>
                                        <a href="{{ route('blogdetalles.home',['id' =>$item->id_noticia, 'categoria'=>$item->categoria]) }}" class="btn-get-started scrollto">ver mas + </a>
                                    </div>
                                </div>
                            </div>
                          @endforeach                         
                            
                        </div>
                        <nav class="blog-pagination justify-content-center d-flex">
                            <ul class="pagination">
                                <ul class="pagination">
                                    <li class="page-item">
                                        {{ $saludables_blog->links() }}
                                    </li>
                
                                </ul>
                            </ul>
                        </nav>
                    </div>
                    <!--=================================================BLOG DE NOTICIAS covid=====================================================-->

                    <div class="container">
                        <div class="row mb-5 justify-content-center text-center">
                            <div class="col-lg-4 mb-5 text-center">
                            </div>
                            <div class="container">
                                <div class="section-title">
                                    <h2><span style="color: #737373;">BLOG DE NOTICIAS COVID-19 </span> <span
                                            style="color: #f57d00;">NEFROUROS</span> </span>
                                    </h2>
                                    <p>Nuestras noticias mas recientes <br> NEFROUROS le actualiza lo que sucede en nuestras
                                        Unidades Renales </p>
                                </div>
                            </div>
                        </div>
                        <div class="row mb-5 justify-content-center text-center">
                            @foreach ($covid_blog as $item)
                            <div class="col-lg-4 col-md-6 mb-5 mb-lg-5">
                                <div class="feature-1 border person text-center">
                                    <img src="{{ $item->imagen_principal }}" width="160px" height="180px">
                                    <div class="feature-1-content">
                                        <h5>{{ $item->nombre_noticia }}</h5>
                                        <span class="position mb-3 d-block" style="color: #f57d00;">{{ $item->fecha_noticia }} </span>
                                        @php
                                            $value = Str::limit($item->detalles_noticia, 120);
                                        @endphp
                                        <p style="text-align: justify">{{ $value}}  </p>
                                        <a href="{{ route('blogdetalles.home',['id' =>$item->id_noticia, 'categoria'=>$item->categoria]) }}" class="btn-get-started scrollto">ver mas + </a>
                                    </div>
                                </div>
                            </div>
                          @endforeach                         
                            
                        </div>
                        <nav class="blog-pagination justify-content-center d-flex">
                            <ul class="pagination">
                                <ul class="pagination">
                                    <li class="page-item">
                                        {{ $covid_blog->links() }}
                                    </li>
                
                                </ul>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
