<?php

namespace Database\Seeders;

use App\Models\blogcategoria;
use Illuminate\Database\Seeder;

class categorias extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $categoria = new blogcategoria();
        $categoria->Categoria = 'Noticias-pacientes';
        $categoria->save();

    }
}
