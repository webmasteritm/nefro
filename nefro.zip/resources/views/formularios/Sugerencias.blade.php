@extends('../layauts.plantilla')
<br><br><br><br>
@section('content')
    <section id="contact" class="contact">

        <div class="container">

            <div class="section-title">
                <h2>Evaluar O Sugerir</h2>
                <p>Gracias por el tiempo que nos dedica para diligenciar este formato. Su opinión es muy importate para
                    nosotros ya que nos permitirá mejorar los servicios ofrecidos a todos los usuarios. </p>
            </div>
        </div>
        <div class="container">
            <div class="mt-5 row">

                <div class="col-lg-4">
                    <div class="info">
                        <div class="address">
                            <i class="icofont-google-map"></i>
                            <h4>Ubicaci&oacute;n</h4>
                            <p>En la seccion sedes del menu principal encontrara informaci&oacute;n detallada de la sede de
                                su interes.</p>
                        </div>

                        <div class="email">
                            <i class="icofont-envelope"></i>
                            <h4>envianos un mensaje:</h4>
                            <p>Nefrouros ofrece a todos nuestros pacientes la posibilidad que contactar,enviar sugerencias o
                                pedir citas por medio de nefrouros.net</p>
                        </div>

                        <div class="phone">
                            <i class="icofont-phone"></i>
                            <h4>Llamanos:</h4>
                            <p>En la seccion sedes del menu principal encontrara informaci&oacute;n detallada de la sede de
                                su interes.</p>
                        </div>

                    </div>

                </div>
                <div class="mt-5 col-lg-8 mt-lg-0">
                    <form method="post" action="{{ route('enviar.sugerencias') }}" class="php-email-form alerta">
                        @csrf
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="evaluar1">Fecha</label>
                                <input type="date" class="form-control " id="evaluar1" name='evaluar1' placeholder="Fecha"
                                    required>
                            </div>

                            <div>
                                <label for="verificacion">Digite este código:1030</label>
                                <input type="text" class="form-control" placeholder="verficacion" name="verificacion" id="verificacion required>
                        
                                    </div>
                                    
                                    <div class=" form-group col-md-6">
                                <label for="sedes">Sede que desea evaluar :</label>
                                <select class="form-control" name='sedes' id="sedes" required>
                                    <option selected>Seleccionar</option>
                                    <option value="gerencianeiva@nefrouros.net">Neiva</option>
                                    <option value=" gerenciapitalito@nefrouros.net">Pitalito</option>
                                    <option value="gerenciaibague@nefrouros.net">Ibague</option>
                                    <option value="gerenciatunja@nefrouros.net">Tunja</option>
                                    <option value="gerenciatunja@nefrouros.net">Duitama</option>
                                    <option value="gerenciamonteria@nefrouros.net">Monter&iacute;a</option>
                                    <option value="gerenciasessalud@nefrouros.net">Yopal</option>
                                    <option value="gerencianefroservicios@nefrouros.net">Barrancabermeja</option>
                                    <option value="gerenciaenvigado@nefrouros.net">Envigado</option>
                                    <option value="gerenciagarzon@nefrouros.net">Garz&oacute;n</option>
                                    <option value="gerencianefroprev.medellin@nefrouros.net">Medellín</option>
                                    <option value="coordinacionnefroprevencionzonanorte@nefrouros.net">Rionegro</option>
                                    <option value="gerenciabarranquilla@nefrouros.net">Barranquilla</option>
                                    <option value=" gerenciaapartado@nefrouros.net">Apartadó</option>
                                    <option value="gerencia.nefrolorica@nefrouros.net">Lorica</option>
                                    <option value="gerenciapuertoasis@nefrouros.net">Puerto Asís</option>
                                    
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="evaluar3">Nombres</label>
                                <input type="text" class="form-control" placeholder="Ejemplo: Andres Felipe Medina"
                                    name='evaluar3' id="evaluar3">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="evaluar4">Email</label>
                                <input type="email" class="form-control" placeholder="Ejemplo: Andres12@gmail.com"
                                    name="evaluar4" id="evaluar4">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="evaluar5">Tel&eacute;fono</label>
                                <input type="text" class="form-control" placeholder="Ejemplo: 317  667 6549" name="evaluar5"
                                    id="evaluar6">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="evaluar6">Entidad Prestadora de Salud (EPS)</label>
                                <input type="text" class="form-control" placeholder=" " name='evaluar6' id="evaluar6"
                                    required>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="evaluar7">¿recomendaría a familiares y amigos la unidad renal? </label>
                                <select id="evaluar7" class="form-control" name='evaluar7' id="evaluar7" required>
                                    <option selected>Seleccionar</option>
                                    <option>Definitivamente si</option>
                                    <option>Probablemente si</option>
                                    <option>Definitivamente no</option>
                                    <option>Probablemente no</option>
                                    <option>No responde. </option>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="evaluar8">¿Cómo evalúa su experiencia respecto a los servicios
                                    recibidos?</label>
                                <select id="evaluar8" class="form-control" name='evaluar8' id="evaluar8" required>
                                    <option selected>Seleccionar</option>
                                    <option>Muy buena</option>
                                    <option>Buena </option>
                                    <option>Regular</option>
                                    <option>Mala </option>
                                    <option>Muy mala </option>
                                    <option>No responde </option>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="evaluar9">Comentario</label>
                                <select id="evaluar9" class="form-control" name='evaluar9' id="evaluar9" required>
                                    <option selected>Seleccionar</option>
                                    <option>Felicitacion </option>
                                    <option>Petición</option>
                                    <option>Sugerencia </option>
                                    <option>Queja </option>
                                </select>
                            </div>

                            <div class="form-group col-md-6">
                                <label for="evaluar10">Servicio que desea evaluar</label>
                                <select id="evaluar10" class="form-control" name='evaluar10' id="evaluar10" required>
                                    <option selected>Seleccionar</option>
                                    <option>Psicología</option>
                                    <option>Nutrición</option>
                                    <option>Trabajo social</option>
                                    <option>Médicos de sala</option>
                                    <option>Profesional de nefrología </option>
                                    <option>Jefes de enfermería </option>
                                    <option>Auxiliares de enfermería </option>
                                    <option>Gerencia </option>
                                    <option>Servicio farmacéutico </option>
                                    <option>Secretaria recepcionista </option>
                                    <option>Servicio de transporte </option>
                                    <option> Técnico de mantenimiento </option>
                                    <option>Orden y aseo de la unidad </option>
                                    <option> Orientadores </option>
                                    <option> Refrigerios </option>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="evaluar11">¿conoce usted los derechos y deberes de la unidad renal?</label>
                                <select id="evaluar11" class="form-control" name='evaluar11' id="evaluar11" required>
                                    <option selected>Seleccionar</option>
                                    <option>Sí </option>
                                    <option>No</option>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="evaluar12">Resumen del comentario</label>
                                <textarea class="form-control" id="evaluar12" name="evaluar12"
                                    placeholder="Describa el motivo de su comentario" required></textarea>
                            </div>
                            <button type="submit" class="btn btn-success" name='btn_send'>Enviar </button>
                    </form>

                </div>

            </div>

        </div>
    </section><!-- End Contact Section -->
@endsection
@section('js')
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    @if ($mensaje = Session::get('success'))
        @if ($mensaje == 'ok')
            <script>
                Swal.fire(
                    'Enviado!',
                    'Se enviaron los datos de cita Correctamente,Pronto recibira una notificacion a su correo eletronico!',
                    'success'
                )

            </script>
        @else
            <script>
                Swal.fire(
                    'Se produjo un error!',
                    'uups! Vaya al parecer hay un problema al enviar su solicitud',
                    'error'
                )

            </script>
        @endif
    @endif
    <script>
        $('.alerta').submit(function(e) {
            e.preventDefault();
            swal.fire({
                title: "Enviar sus datos?",
                text: "por favor verifique y confirme!",
                type: "warning",
                showCancelButton: !0,
                confirmButtonText: "Si,Acepto!",
                cancelButtonText: "No, cancelar!",
                reverseButtons: !0
            }).then((result) => {
                if (result.value) {
                    this.submit();
                } else if (result.dismiss === Swal.DismissReason.cancel) {
                    Swal.fire(
                        'Cancelado',
                        'Se cancelo el envio vuelve a intentarlo!',
                        'error'
                    )
                }
            })
        });

    </script>
@endsection
