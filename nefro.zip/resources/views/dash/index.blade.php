@extends('adminlte::page')
<link rel="stylesheet" href="/assets/css/style.css">
@section('title', 'Nefrouros|Dashboard')

@section('content_header')

@stop

@section('content')


@endsection

@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')
    <script>
        console.log('Hi!');
    </script>
@stop
