<div class="mt-5 col-lg-8 mt-lg-0">
    <form method="post" action="{{ route('enviar.contactenos') }}" class="php-email-form alerta">
        @csrf
        <div class="form-row">
            <div class="form-group col-md-6">
                <label for="nombre">Nombres</label>
                <input type="text" class="form-control" placeholder="Ejemplo: Andres Felipe Medina" name='nombre'
                    id="nombre" required>
            </div>
            <div class="form-group col-md-6">
                <label for="email">Email</label>
                <input type="email" class="form-control" placeholder="Ejemplo: Andres12@gmail.com" name="email"
                    id="email" required>
            </div>
            <div class="form-group col-md-6">
                <label for="telefono">Tel&eacute;fono</label>
                <input type="text" class="form-control" placeholder="Ejemplo: 317  667 6549" name="telefono"
                    id="telefono" required>
            </div>
            <div class="form-group col-md-6">
                <label for="direccion">Dirección</label>
                <input type="text" class="form-control" placeholder="Ejemplo:Carrera 15 - calle 9 esquina "
                    name="direccion" id="direccion" required>
            </div>

            <div>
                <label for="verificacion">Digite este código:1030</label>
                <input type="text" class="form-control" placeholder="verficacion" name="verificacion" id="verificacion required>

            </div>


            <div class=" form-group col-md-6">
                <label for="sedes">Sede que desea contactar(obligatorio):</label>
                <select id="sedes" class="form-control" name='sedes' id="sedes" required>
                    <option selected>Seleccionar</option>
                    <option value="gerencianeiva@nefrouros.net">Neiva</option>
                    <option value="gerenciapitalito@nefrouros.net">Pitalito</option>
                    <option value="gerenciaibague@nefrouros.net">Ibague</option>
                    <option value="gerenciatunja@nefrouros.net">Tunja</option>
                    <option value="gerenciatunja@nefrouros.net">Duitama</option>
                    <option value="gerenciamonteria@nefrouros.net">Monter&iacute;a</option>
                    <option value="gerenciasessalud@nefrouros.net">Yopal</option>
                    <option value="gerencianefroservicios@nefrouros.net">Barrancabermeja</option>
                    <option value="gerenciaenvigado@nefrouros.net">Envigado</option>
                    <option value="gerenciagarzon@nefrouros.net">Garz&oacute;n</option>
                    <option value="gerencianefroprev.medellin@nefrouros.net">Nefroprevenci&oacute;n</option>
                    <option value="coordinacionnefroprevencionzonanorte@nefrouros.net">Rionegro</option>
                    <option value="gerenciabarranquilla@nefrouros.net ">Barranquilla</option>
                </select>
            </div>
            <div class="form-group col-md-6">
                <label for="mensaje">Mensaje</label>
                <textarea class="form-control" id="mensaje" name="mensaje" placeholder="Describa en motivo"
                    required></textarea>
            </div>
            <div class="form-group col-md-6">
                <button type="submit" class="btn btn-success" name='btn_send'>Contactar </button>
            </div>
    </form>

</div>
