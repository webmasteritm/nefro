<?php

namespace Database\Seeders;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Seeder;

class meses extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('calendario_meses')->insert([
            'meses'=>'Diciembre',
            'id_mesdate'=>'12'

        ]);
    }


}
