
<?php $__env->startSection('content'); ?>
    <!--================Blog Area =================-->
    <section id="gallery" class="gallery">

        <div class="container">
            <br>
            <div class="container-fluid">
                <div class="row no-gutters">
                    <h2 style="align-items: center"><span style="color: #737373;">ACTIVIDADES DE NUESTROS </span> <span
                            style="color: #f57d00;"> PACIENTES</span>
                        </span>
                    </h2>

                </div>
            </div>
            <br><br>
            
            
        </div>
    </section> 

            <div class="pb-0 site-section">
                <div class="container">
                    <div class="mb-3 text-center row justify-content-center">
                        <div class="mb-4 text-center col-lg-3">
                        </div>
                        <div class="row">
                            <div class="mb-5 col-lg-4 col-md-6 mb-lg-5">
                                <div class="text-center border feature-1 person">
                                    <img src="assets/img/neiva.jpg" alt="Image" class="img-fluid">
                                    <div s class="feature-1-content">

                                    </div>
                                </div>
                                <a href="<?php echo e(route('actividades.galeria', ['id' => '1', 'sede' => 'Neiva'])); ?>"
                                    class="btn-get-started scrollto">Sede Neiva </a>
                            </div>
                            <div class="mb-5 col-lg-4 col-md-6 mb-lg-5">
                                <div class="text-center border feature-1 person">
                                    <img src="assets/img/barranquilla.png" alt="Image" class="img-fluid">

                                </div>
                                <a href="<?php echo e(route('actividades.galeria', ['id' => '2', 'sede' => 'Barranquilla'])); ?>"
                                    class="btn-get-started scrollto"> Sede Barranquilla </a>
                            </div>
                            <div class="mb-5 col-lg-4 col-md-6 mb-lg-5">
                                <div class="text-center border feature-1 person">
                                    <img src="assets/img/medellin.png" alt="Image" class="img-fluid">
                                    <div class="feature-1-content">

                                    </div>
                                </div>
                                <a href="<?php echo e(route('actividades.galeria', ['id' => '3', 'sede' => 'Medellin'])); ?>"
                                    class="btn-get-started scrollto">Sede Medellín </a>
                            </div>

                            <div class="mb-5 col-lg-4 col-md-6 mb-lg-5">
                                <div class="text-center border feature-1 person">
                                    <img src="assets/img/rionegro.png" alt="Image" class="img-fluid">

                                </div>
                                <a href="<?php echo e(route('actividades.galeria', ['id' => '4', 'sede' => 'Rionegro'])); ?>"
                                    class="btn-get-started scrollto">Sede Rionegro </a>
                            </div>
                            <div class="mb-5 col-lg-4 col-md-6 mb-lg-5">
                                <div class="text-center border feature-1 person">
                                    <img src="assets/img/garzon.png" alt="Image" class="img-fluid">

                                </div>
                                <a href="<?php echo e(route('actividades.galeria', ['id' => '5', 'sede' => 'Garzon'])); ?>"
                                    class="btn-get-started scrollto">Sede Garzón </a>
                            </div>
                            <div class="mb-5 col-lg-4 col-md-6 mb-lg-5">
                                <div class="text-center border feature-1 person">
                                    <img src="assets/img/envigado.png" alt="Image" class="img-fluid">

                                </div>
                                <a href="<?php echo e(route('actividades.galeria', ['id' => '6', 'sede' => 'Envigado'])); ?>"
                                    class="btn-get-started scrollto">Sede Envigado</a>
                            </div>
                            <div class="mb-5 col-lg-4 col-md-6 mb-lg-5">
                                <div class="text-center border feature-1 person">
                                    <img src="assets/img/pitalito.png" alt="Image" class="img-fluid">

                                </div>
                                <a href="<?php echo e(route('actividades.galeria', ['id' => '7', 'sede' => 'Pitalito'])); ?>"
                                    class="btn-get-started scrollto">Sede Pitalito </a>
                            </div>
                            <div class="mb-5 col-lg-4 col-md-6 mb-lg-5">
                                <div class="text-center border feature-1 person">
                                    <img src="assets/img/monteria.png" alt="Image" class="img-fluid">

                                </div>
                                <a href="<?php echo e(route('actividades.galeria', ['id' => '8', 'sede' => 'Monteria'])); ?>"
                                    class="btn-get-started scrollto">Sede Montería</a>
                            </div>
                            <div class="mb-5 col-lg-4 col-md-6 mb-lg-5">
                                <div class="text-center border feature-1 person">
                                    <img src="assets/img/yopal.png" alt="Image" class="img-fluid">

                                </div>
                                <a href="<?php echo e(route('actividades.galeria', ['id' => '9', 'sede' => 'Yopal'])); ?>"
                                    class="btn-get-started scrollto">Sede Yopal </a>
                            </div>
                            <div class="mb-5 col-lg-4 col-md-6 mb-lg-5">
                                <div class="text-center border feature-1 person">
                                    <img src="assets/img/barranca.png" alt="Image" class="img-fluid">

                                </div>
                                <a href="<?php echo e(route('actividades.galeria', ['id' => '10', 'sede' => 'Barrancabermeja'])); ?>"
                                    class="btn-get-started scrollto">Sede Barrancabermeja </a>
                            </div>
                            <div class="mb-5 col-lg-4 col-md-6 mb-lg-5">
                                <div class="text-center border feature-1 person">
                                    <img src="assets/img/ibague.png" alt="Image" class="img-fluid">

                                </div>
                                <a href="<?php echo e(route('actividades.galeria', ['id' => '11', 'sede' => 'Ibague'])); ?>"
                                    class="btn-get-started scrollto">Sede Ibagué</a>
                            </div>
                            <div class="mb-5 col-lg-4 col-md-6 mb-lg-5">
                                <div class="text-center border feature-1 person">
                                    <img src="assets/img/tunja.png" alt="Image" class="img-fluid">

                                </div>
                                <a href="<?php echo e(route('actividades.galeria', ['id' => '12', 'sede' => 'Tunja'])); ?>"
                                    class="btn-get-started scrollto">Sede Tunja </a>
                            </div>
                            <div class="mb-5 col-lg-4 col-md-6 mb-lg-5">
                                <div class="text-center border feature-1 person">
                                    <img src="assets/img/duitama.jpg" alt="Image" class="img-fluid">

                                </div>
                                <a href="<?php echo e(route('actividades.galeria', ['id' => '13', 'sede' => 'Duitama'])); ?>"
                                    class="btn-get-started scrollto">Sede Duitama</a>
                            </div>
                            <div class="mb-5 col-lg-4 col-md-6 mb-lg-5">
                                <div class="text-center border feature-1 person">
                                    <img src="assets/img/apartado.png" alt="Image" class="img-fluid">

                                </div>
                                <a href="<?php echo e(route('actividades.galeria', ['id' => '14', 'sede' => 'Apartadó'])); ?>"
                                    class="btn-get-started scrollto">Sede Apartadó</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        

    </section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layauts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nefro\resources\views/actividadesPacientes.blade.php ENDPATH**/ ?>