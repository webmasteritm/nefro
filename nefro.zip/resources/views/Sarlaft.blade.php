@extends('layauts.plantilla')
@section('content')

    <section>
        
        <section class="blog_area section-padding">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 mb-5 mb-lg-0">
                        <div class="blog_left_sidebar">
                            <article class="blog_item">
                                <div class="blog_details">
                                    <a class="d-inline-block" href="#">
                                        <h2>SISTEMA DE ADMINISTRACION DE RIESGO DE LAVADO DE ACTIVOS Y DE LAFINANCIACIÓN DEL
                                            TERRORISMO – SARLAFT.</h2>
                                    </a>
                                    <p class="section_text text-justify"><b>NEFROUROS MOM S.A.S,</b> se permite certificar
                                        que es una Institución Prestadora de Servicios de Salud, debidamente constituida en
                                        Colombia y que se encuentra vigilada por la Superintendencia Nacional de Salud. De
                                        acuerdo con Circular Externa 0009 del 21 de abril de 2016, las instrucciones
                                        impartidas por la Superintendencia Nacional de Salud, y según las recomendaciones y
                                        mejores prácticas internacionales en esta materia,
                                        establecidas principalmente por el GAFI (Grupo de Acción Financiera Internacional
                                        sobre Lavado de Dinero)
                                        <b>NEFROUROS MOM S.A.S,</b> ha adoptado e implementado un Sistema de Administración
                                        del Riesgo del Lavado de Activos y la Financiación del Terrorismo, denominado
                                        SARLAFT, el cual incluye las políticas, controles
                                        y procedimientos que buscan la debida diligencia para prevenir el uso de la Entidad
                                        en actividades delictivas. Lo anterior incluye entre otros aspectos, el conocimiento
                                        del cliente y de sus operaciones con la Entidad,
                                        la definición de los segmentos de mercado, monitoreo de transacciones, capacitación
                                        al personal y colaboración con las autoridades competentes.
                                        <b>FUNDACIÓN NEFROUROS, NEFROBOYACÁ S.A.S, NEFROSERVICIOS S.A.S Y
                                            SES SALUD S.A,</b> no se encuentran obligadas a adoptar e implementar el Sistema
                                        de Administración del Riesgo del Lavado de Activos y la Financiación del Terrorismo,
                                        denominado
                                        SARLAFT, el cual incluye las políticas, controles y procedimientos que buscan la
                                        debida diligencia para prevenir el uso de la Entidad en actividades delictivas.
                                        <b>FUNDACIÓN NEFROUROS, NEFROBOYACÁ S.A.S, NEFROSERVICIOS S.A.S Y
                                            SES SALUD S.A, </b>aunque no se encuentran obligados a implementar SARLAFT,
                                        realizan análisis de contrapartes, se verifican antecedentes ante listas de
                                        presuntos vínculos con
                                        lavados de activos y financiación terrorista, se analiza la información financiera
                                        de contrapartes y responde las solicitudes de información SARLAFT ante otras
                                        entidades.
                                    </p>
                                </div>
                            </article>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <br><br><br>
                        <div class="blog_right_sidebar">
                            <aside class="single_sidebar_widget post_category_widget">
                                <h4 class="widget_title">Noticias del mes</h4>
                                <ul class="list cat-list">
                                    <li>
                                        <a href="#" class="d-flex">
                                            <p>Medidas más efectivas para prevenir el COVID-19</p>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" class="d-flex">
                                            <p>Medidas más efectivas para prevenir el COVID-19</p>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" class="d-flex">
                                            <p>Paciente del mes</p>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" class="d-flex">
                                            <p>¿Qué son las etapas de la enfermedad renal?</p>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" class="d-flex">
                                            <p>¿Qué puede hacer para proteger sus riñones?</p>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" class="d-flex">
                                            <p>Vivir bien con enfermedad renal</p>
                                        </a>
                                    </li>
                                </ul>
                            </aside>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </section>
@endsection
