
<?php $__env->startSection('title', 'NEFROUROS::Subir-actividad'); ?>
<?php $__env->startSection('content'); ?>
    <!--================Blog Area =================-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous">
    </script>

    <section>


        <div class="container">
            <div class="container-fluid">
                <div class="row no-gutters">

                    <?php $__currentLoopData = $sedesactividad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3 col-md-4">
                            <div class="gallery-item">
                                <a href="<?php echo e(route('actividades.galeria', ['sede' => $item->sede, 'id' => $item->id])); ?>"
                                    class="" data-gall="gallery-item">
                                    <img src="https://nefrouros.net/<?php echo e($item->imagen_principal); ?>" class="img-fluid">
                                    <div class="text-center experts_name">
                                        <h5 style="color: black"><?php echo e($item->nombre_actividad); ?></h5>
                                        <h6 style="color: black"><?php echo e($item->descripcion_actividad); ?></h6>
                                        <span style="color: black"><?php echo e($item->sede); ?> <br></span>

                                    </div>
                                </a>


                                <a href="Editar-actividad" style="margin-left: 25%;" class="btn btn-primary">Editar</a>

                                <button type="button" class="btn btn-primary">Borrar</button>
                                <br>
                                <br>


                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>

        </div>

        <nav class="blog-pagination justify-content-center d-flex">
            <ul class="pagination">
                <ul class="pagination">
                    <li class="page-item">
                        <?php echo e($sedesactividad->links()); ?>

                    </li>

                </ul>
            </ul>
        </nav>
    </section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\dashboard\resources\views/galeria/carga-actividad.blade.php ENDPATH**/ ?>