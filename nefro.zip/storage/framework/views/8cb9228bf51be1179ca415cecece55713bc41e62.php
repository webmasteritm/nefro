
<?php $__env->startSection('content'); ?>
<section id="hero">
    <div id="heroCarousel" class="carousel slide carousel-fade" data-ride="carousel">

        <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>

        <div class="carousel-inner" role="listbox">
            <!-- Slide 1 -->
            <div class="carousel-item active" style="background-image: url(../assets/img/sedes/UR-Pitalito/pitalito4.jpg)">
                <div class="container">
                    <h2><span style="color: #F57D00;">NEFROUROS</span> <span style="color: #737373;">SEDE PITALITO </span></h2>
                    <a href="<?php echo e(route('citas.home')); ?>" class="btn-get-started scrollto">Citas en linea</a>
                </div>
            </div>
            <!-- Slide 2 -->
            <div class="carousel-item" style="background-image: url(../assets/img/sedes/UR-Pitalito/pitalito3.jpg)">
            </div>
            <!-- Slide 3 -->
            <div class="carousel-item" style="background-image: url(../assets/img/sedes/UR-Pitalito/pitalito2.jpg)">
            </div>
        </div>
        <div class="carousel-item" style="background-image: url(../assets/img/sedes/UR-Pitalito/pitalito1.jpg)">
        </div>
    </div>

    <a class="carousel-control-prev" href="#heroCarousel" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon icofont-simple-left" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>

    <a class="carousel-control-next" href="#heroCarousel" role="button" data-slide="next">
        <span class="carousel-control-next-icon icofont-simple-right" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>

    </div>
</section>
<!-- End Hero -->

<br></br>
<br></br>
<br></br>
<br></br>
<br></br>
<section id="contact" class="contact">

    <div class="container">
        <div class="section-title">
            <h2><span style="color: #F57D00;">NEFROUROS</span> <span style="color: #737373;">SEDE PITALITO</span></h2>
            <p>Puede contactar nuestra unidad renal en la ciudad de pitalito ,diligencie el formulario y verifique que sus datos esten correctos. </p>
        </div>
    </div>
    <div>
        <iframe style="border:0; width: 100%; height: 350px;" src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d7975.484616923895!2d-76.04626173063401!3d1.8483951511311436!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x38ae1d1f29042e5a!2sNefrouros%20Pitalito!5e0!3m2!1ses-419!2sco!4v1601760986456!5m2!1ses-419!2sco" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
    </div>

    <div class="container">
        <div class="row mt-5">
            <div class="col-lg-4">
                <div class="info">
                    <div class="address">
                        <i class="icofont-google-map"></i>
                        <h4>Ubicación:</h4>
                        <p> Carrera 1 No 5-40 Barrio Los Lagos
                            <p>Pitalito, Huila</p>
                        </p>
                    </div>

                    <div class="email">
                        <i class="icofont-envelope"></i>
                        <h4>Email:</h4>
                        <p>gerenciapitalito@nefrouros.net</p>
                    </div>

                    <div class="phone">
                        <i class="icofont-phone"></i>
                        <h4>Teléfonos:</h4>
                        <p>(8)836 5246 – (03)317 667 1994</p>
                    </div>

                </div>

            </div>

            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.formulario-contacto','data' => []]); ?>
<?php $component->withName('formulario-contacto'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

        </div>

    </div>
</section>  

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?> 


<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.formulario-script','data' => []]); ?>
<?php $component->withName('formulario-script'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layauts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nefro\resources\views/sedes/sede-2-Pitalito.blade.php ENDPATH**/ ?>